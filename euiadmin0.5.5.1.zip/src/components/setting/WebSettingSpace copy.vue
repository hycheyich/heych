<template>
  <div>
    <el-card shadow="never">
      <div slot="header">网站设置</div>
      <div style="min-height:60vh"></div>
    </el-card>
  </div>
</template>