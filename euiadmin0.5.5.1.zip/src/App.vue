<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>

export default {

}
</script>
<style scoped>
#app {
  background-color: #EBEEF5;
}
</style>

