



## django 01

### 1.django的命令

1. 下载

    pip  install django==1.11.25 -i 源

    2. 创建项目

    django-admin startproject  项目名

2. 启动项目

    cd 项目的根目录

    python  manage.py runserver   # 127.0.0.1:8000

    python  manage.py runserver 80   # 127.0.0.1:80

    python  manage.py runserver 0.0.0.0:80   # 0.0.0.0:80

3. 创建APP

    python  manage.py  startapp  app名称

4. 数据库迁移的命令

    python  manage.py  makemigrations   #  检查已经注册的APP下的models.py的变更记录

    python  manage.py  migrate   # 将变更记同步到数据库中

### 2.django的配置

​	TEMPLATES   模板  DIRS  [ os.path.join(BASE_DIR,'templates') ]

​	 静态文件

​			STATIC_URL = '/static/'  # 静态文件的别名

​			STATICFILES_DIRS = [

​					os.path.join(BASE_DIR,'static')

​			]

​		注册的app

​		INSTALLED_APPS = [

​				'app01'

​				'app01.apps.App01Config'

​	   ]

​	 中间件

​			注释掉csrf中间件   可以提交POST请求

​	 数据库的配置

​			ENGINE  :    mysql

​			NAME:   数据库的名称

​			HOST:   ip 

​			PORT :   3306

​			USER :  用户名

​			PASSWORD :  密码

​    

### 3.django使用mysql数据库的流程

1. 创建一个mysql数据库

2. 数据库settings中的配置

    ​	 	   ENGINE  :    mysql

    ​			NAME:   数据库的名称

    ​			HOST:   ip 

    ​			PORT :   3306

    ​			USER :  用户名

    ​			PASSWORD :  密码

3. 告诉django使用pymysql连接数据库

    写在与settingst同级目录下的`__init__.py`中：

    import pymysql

    pymysql.install_as_MySQLdb()

    ```
    4. 在models写类（继承models.Model）:
    ```

    ```python
    class Publisher(models.Model):
        pid = models.AutoField(primary_key=True)
        name = models.CharField(max_length=32)  # varchar(32)
        
        
    class Book(models.Model):
        title = models.CharField(max_length=32)  # varchar(32)
        pub = models.ForeignKey('Publisher',on_delete=models.CASCADE)
        
        
    class Author(models.Model):
        name = models.CharField(max_length=32)  # varchar(32)
        books = models.ManyToManyField(Book)  # 生成第三张表  不会在Author表中生成字段
    ```

    ```
    5. 执行数据库迁移的命令
    ```

    python  manage.py  makemigrations   #  检查已经注册的APP下的models.py的变更记录

    python  manage.py  migrate   # 将变更记同步到数据库中

### 4.request  请求相关的内容

​	request.GET     url上携带的参数   {}    get()

​    request.POST   POST请求提交的数据   {}    get()     getlist()

​	request.method  请求方法 GET POST 

​	HTTP请求的方法：HTTP/1.1协议中共定义了八种方法（有时也叫“动作”），来表明Request-URL指定的资源不同的操作方式HTTP1.0定义了三种请求方法： GET, POST 和 HEAD方法。HTTP1.1新增了五种请求方法：OPTIONS, PUT, DELETE, TRACE 和 CONNECT 方法

![1572424597140](../../python%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0/django/django02.assets/1572424597140.png)

状态码：

200OK 当您的操作将在响应正文中返回数据时，出现此结果。

204No Content当您的操作成功，但不在响应正文中返回数据时，出现此结果。

304Not Modified（重定向） 当测试实体自上次检索以来是否被修改时，出现此结果。

403Forbidden 客户端错误

401Unauthorized客户端错误

413Payload Too Large（客户端错误）当请求长度过长时，出现此结果。

400BadRequest（客户端错误）当参数无效时，出现此结果。

404Not Found（客户端错误）当资源不存在时，出现此结果。

405Method Not Allowed（客户端错误）由于方法和资源组合不正确而出现此错误。 例如，您不能对一个实体集合使用 DELETE 或 PATCH。

412Precondition Failed 客户端错误

501Not Implemented（服务器错误）当未实施某个请求的操作时，出现此结果。

503Service Unavailable（服务器错误）当 Web API 服务不可用时，出现此结果。

### 5.响应

​	HttpResponse(‘字符串’)    返回的字符串‘

​	render(request,'模板的文件名',{})      返回的是 完整的页面

​	redirect（重定向的地址 ）  重定向

### 6.ORM

​	对象关系映射 

​	对应关系：

​	 类   ——》  表

​	对象  ——》  数据行（记录）

​	属性  ——》  字段

具体的操作：

  查询

```python
from app01 import  models
models.Publisher.objects.all()   #  查询所有的数据  QuerySet  对象列表
models.Publisher.objects.get(name='xxx')   #  查询满足条件的一条数据（唯一存在） 对象 不存在或者多个就报错
ret = models.Publisher.objects.filter(name='xxx')   #  查询满足条件所有的数据   对象列表
ret[0]
ret.first()   #  获取第一个对象  取不到就是None


for i in pubs：
	i.name
    i.pid   i.pk
    
book_obj.title
book_obj.pub    #  外键关联的对象
book_obj.pub_id    #  外键关联对象的id


author_obj.name
author_obj.books   # 关系管理对象
author_obj.books.all()   # 所关联的所有的对象   [book,book]
```

新增

```python
ret =  models.Publisher.objects.create(name='xxxx')  #  新增数据  返回一个对象
obj = models.Publisher（name='xxxx'）
obj.save()

models.Book.objects.create(title='xxxx',pub=出版社对象) 
models.Book.objects.create(title='xxxx',pub_id=出版社对象id) 

obj = models.Author.objects.create(name='xxx')
obj.books.set([book的id])
```

删除

```
 models.Publisher.objects.filter(pk=pk).delete()
 book_obj.delete()
```

编辑

```
book_obj.title = 'xxxx'
book_obj.pub_id =id
book_obj.save()

author_obj.name='xxx'
author_obj.save()
author_obj.books.set([book的id，book的id，book的id])
```

### 7.模板

```
render(request,'模板的文件名'，{k1:v1})

变量
{{  k1 }}

for循环
{% for i in list %}
	{{ forloop.counter }}
	{{ i }}
{% endfor %}

if判读

{% if 条件 %}
	满足条件后的结果
{% endif  %}


{% if 条件 %}
	满足条件后的结果
{% else %}	
	不满足条件后的结果
{% endif  %}


{% if 条件 %}
	满足条件后的结果
{% elif 条件1 %}
	满足条件后的结果	
{% else %}	
	不满足条件后的结果
{% endif  %}

```

---

## django 02

### 1.MVC 和MTV

著名的MVC模式：所谓MVC就是把web应用分为模型(M),控制器(C),视图(V)三层；他们之间以一种插件似的，松耦合的方式连接在一起。

模型负责业务对象与数据库的对象(ORM),视图负责与用户的交互(页面)，控制器(C)接受用户的输入调用模型和视图完成用户的请求

![1572250338908](django02.assets/1572250338908.png)

![1572250502954](django02.assets/1572250502954.png)

Django的MTV模式本质上与MVC模式没有什么差别，也是各组件之间为了保持松耦合关系，只是定义上有些许不同，Django的MTV分别代表：

​       Model(模型)：负责业务对象与数据库的对象(ORM)

​       Template(模版)：负责如何把页面展示给用户

​       View(视图)：负责业务逻辑，并在适当的时候调用Model和Template

​       此外，Django还有一个url分发器，它的作用是将一个个URL的页面请求分发给不同的view处理，view再调用相应的Model和Template

![1572250364865](django02.assets/1572250364865.png)

MVC  

​	M:  model    模型 数据库交互

​	V：view  视图   展示给用户看的  HTML 

​    C ：controller   控制器  业务逻辑  传递指令

MTV:

​	M:  model  模型   ORM

​	T:  template  模板   

​	V:  view   视图  业务逻辑





### 2.django模板语言

#### 1.点的使用

{{  变量 }}

  .索引  . key  .属性   .方法

优先级：

key   >   属性或者方法  >  数字索引

#### 2.过滤器

  {{ value|filter_name }}

  {{ value|filter_name:参数 }}

##### 内置的过滤器

https://docs.djangoproject.com/en/1.11/ref/templates/builtins/#built-in-filter-reference

default

```
{{  变量|default:'默认值'  }}   变量不存在或者为空 显示默认值
```

filesizeformat    显示文件大小

upper  lower  join 

add

```
{{ 2|add:'2'  }}   数字加法
{{ 'a'|add:'b'  }}   字符串的拼接
{{ [1,2]|add:[3,4]  }}   列表的拼接
```

length  返回变量的长度

slice    切片

```
{{ string|slice:'-1::-1' }}
```

date  日期格式化

```
{{ now|date:'Y-m-d H:i:s' }}
```

date 日期时间格式化  {{  日期时间类型|date:'Y-m-d H:i:s'  }}     datetime:   Y-m-d  H:M:S

​		settings:

​		USE_L10N =  False

​		DATETIME_FORMAT = 'Y-m-d H:i:s'

​		DATE_FORMAT = 'Y-m-d'

safe   前面的内容不用转义  在模板中使用

```
from django.utils.safestring import mark_safe  # py文件中用
```

##### 自定义过滤器

safe

```
{{ a|safe }}  告诉django不需要进行转义 

```

##### 自定义过滤器

1. 在app下创建一个名叫templatetags的python包  （templatetags名字不能改）

2. 在包内创建py文件 （文件名可自定义 my_tags.py）

3. 在python文件中写代码：

    ```
    from django import template
    register = template.Library()  # register名字不能错
    ```

4. 写上一个函数 + 加装饰器

    ```
    @register.filter
    def str_upper(value,arg):  # 最多两个参数
        ret = value+arg
        return ret.upper()
    ```

使用：

​	在模板中

```
{% load my_tags  %}  加载过滤器
{{ 'alex'|str_upper:'dsb'  }}
```



#### 3.for 

```python
{%  for i in list %}
	{{ forloop.counter }}
	{{ i }}
{% endfor  %}

{{ forloop.counter }}      循环的索引 从1开始
{{ forloop.counter0 }}     循环的索引 从0开始
{{ forloop.revcounter }}   循环的索引(倒叙) 到1结束
{{ forloop.revcounter0 }}   循环的索引(倒叙) 到0结束
{{ forloop.first }}        判断是否是第一次循环  是TRUE
{{ forloop.last }}         判断是否是最后一次循环  是TRUE
{{ forloop.parentloop }}   当前循环的外层循环的相关参数
```

```python
 {% for tr in table %}
            <tr>
                {% for td in tr %}
                    <td > {{ td }} </td>
                {% endfor %}
            </tr>
        {% empty %}
            <tr> <td colspan="4" >没有数据</td> </tr>
{% endfor %}
```

if

```python
{% if alex.age == 84 %}
    当前已经到了第二个坎了
{% elif alex.age == 73 %}
    当前已经到了第一个坎了
{% else %}
    不在坎上，就在去坎上的路上
{% endif %}
```

注意：

```
1. 不支持算数运算  + - * / % 
```

2. 不支持连续判断    10 > 5 > 1  false

with

```python
{% with p_list.0.name as alex_name %}
    {{ alex_name }}
    {{ alex_name }}
    {{ alex_name }}
    {{ alex_name }}
{% endwith %}

{% with alex_name=p_list.0.name   %}
    {{ alex_name }}
    {{ alex_name }}
    {{ alex_name }}
    {{ alex_name }}
{% endwith %}
"""
只可以再with内部区域使用别名，不可以在外部使用
"""
```

csrf 跨站请求伪造：

- 什么是跨站请求攻击？
    - 攻击者通过一些技术手段欺骗用户的浏览器去访问一个自己曾经认证过的网站并运行一些操作（如发邮件，发消息，甚至财产操作如转账和购买商品）。由于浏览器曾经认证过，所以被访问的网站会认为是真正的用户操作而去运行。这利用了web中用户身份验证的一个漏洞：**简单的身份验证只能保证请求发自某个用户的浏览器，却不能保证请求本身是用户自愿发出的**。
    - ![1572334956072](django02.assets/1572334956072.png)
- django的CSRF认证：
    - csrf原理
        - csrf要求发送post,put或delete请求的时候，是先以get方式发送请求，服务端响应时会分配一个随机字符串给客户端，客户端第二次发送post,put或delete请求时携带上次分配的随机字符串到服务端进行校验
    - django中的csrf中间件
        - 'django.middleware.csrf.CsrfViewMiddleware',
    - django中间件的执行流程
        - django中间件最多定义5个方法
            - process_request
                process_response
                process_view
                process_exception
                process_template_response
        - 执行顺序
            - 1.请求进入到Django后，会按中间件的注册顺序执行每个中间件中的process_request方法
                如果所有的中间件的process_request方法都没有定义return语句，则进入路由映射，进行url匹配
                否则直接执行return语句，返回响应给客户端
            - 2.依次按顺序执行中间件中的process_view方法
                如果某个中间件的process_view方法没有return语句，则根据第1步中匹配到的URL执行对应的视图函数或视图类
                如果某个中间件的process_view方法中定义了return语句，则后面的视图函数或视图类不会执行,程序会直接返回
            - 3.视图函数或视图类执行完成之后，会按照中间件的注册顺序逆序执行中间件中的process_response方法
                如果中间件中定义了return语句，程序会正常执行，把视图函数或视图类的执行结果返回给客户端
                否则程序会抛出异常
            - 4.程序在视图函数或视图类的正常执行过程中
                如果出现异常，则会执行按顺序执行中间件中的process_exception方法
                否则process_exception方法不会执行
                如果某个中间件的process_exception方法中定义了return语句，则后面的中间件中的process_exception方法不会继续执行了
            - 5.如果视图函数或视图类中使用render方法来向客户端返回数据，则会触发中间件中的process_template_response方法

源码分析可参照：https://www.cnblogs.com/renpingsheng/p/9756051.html

#### 4.母版和继承

母版：

```
1. 就是一个HTML页面，提取到多个页面的公共部分；
```

2. 定义block块，留下位置，让子页面进行填充

继承：

```
1. 写{% extends  ‘母版的名字’ %}
```

2. 重写block块

注意点：

​	1. {% extends 'base.html' %}   母版的名字有引号的  不带引号会当做变量

2. {% extends 'base.html' %} 上不要写内容，想显示的内容要写在block块中
3. 多定义点block块，有css  js 

#### 5.组件

一小段HTML代码   ——》 nav.html

```
{% include 'nav.html' %}
```

#### 6.静态文件

```
{% load static %}
{% static '相对路径' %}

{% get_static_prefix %}    获取静态文件的别名
```

如果不想每次在模版中加载静态文件都使用load加载static标签，那么可以在settings.py中的TEMPLATES/OPTIONS添加'builtins':['django.templatetags.static']，这样以后在模版中就可以直接使用static标签，而不用手动的load了。
注意： 位置不要添加错误了

![1572336222602](django02.assets/1572336222602.png)

#### 7.simple_tag  和  inclusion_tag

自定义simple_tag：

1. 在app下创建一个名为templatetags的python包;

2. 在包内创建py文件 (任意指定，my_tags.py) 

3. 在py文件中写代码

    ```
    from  django import template
    register = template.Library()   #  register名字不能错
    ```

4. 写函数 +  加装饰器

    ```
    @register.simple_tag
    def str_join(*args, **kwargs):
        return '*'.join(args) + '_'.join(kwargs.values())  
        
        
    @register.inclusion_tag('page.html')
    def page(num):
        return {'num':range(1,num+1)}
        
    # 在templates写page.html
    ```

使用：

​		模板中使用：

```python
{% load my_tags  %}
{{ 变量|str_upper：‘参数’ }}

{% str_join '1' '2' '3' k1='4' k2='5'  %}

{% page 10 %}
```

inclusion_tag:多用于返回html代码片段



### 3.FBV和CBV

FBV   function based view 在视图里使用函数处理请求

CBV   class based view  在视图里使用类处理请求

**CBV**
*核心知识点：*
1、继承from django.views improt View
2、覆写get和post方法，（注意传递request参数）
3、路由使用：模块名.类名.as_view()

定义CBV：

```python
from django.views import View
class PublisherAdd(View):
    
    def get(self,request):
        # 处理get请求的逻辑
        return response
    
    def post(self,request):
        # 处理post请求的逻辑
        return response
```

对应关系：

```python
url(r'publichser_add/',views.PublisherAdd.as_view())
```

#### 1.as_view的流程

1. 程序加载时，执行View中as_view的方法 ，返回一个view函数。

2. 请求到来的时候执行view函数：

    1. 实例化类 ——》 self

    2. self.request = request 

    3. 执行self.dispatch(request, *args, **kwargs)

        1. 判断请求方式是否被允许：

            1. 允许

                通过反射获取当前对象中的请求方式所对应的方法

                handler = getattr(self, request.method.lower(), self.http_method_not_allowed)

            2. 不允许

                handler = self.http_method_not_allowed

                3. 执行handler  获取到结果，最终返回给django

url的流程

1. ​	url(regex, view, kwargs=None, name=None),判断是否可调用View

2. ```
    url(regex, view, kwargs=None, name=None):
    ```

#### 2.django中给视图加装饰器

FBV 直接给函数添加装饰器

CBV

from django.utils.decorators import method_decorator

1. 加在方法上

    ```
    @method_decorator(wrapper)
    def get(self,request):
    ```

2. 加 在dispatch方法上

    ```
    @method_decorator(wrapper)
        def dispatch(self, request, *args, **kwargs):
            ret = super().dispatch(request, *args, **kwargs)
            return ret
    
    
    @method_decorator(wrapper, name='dispatch')
    class PublisherAdd(View):
    ```

3. 加在类上

    ```
    @method_decorator(wrapper, name='post')
    @method_decorator(wrapper, name='get')
    class PublisherAdd(View):
    ```

#### 4.request

```python 
request.method    # 请求方式
request.GET		#  URL上携带的参数
request.POST	# POST请求提交的数据   enctype="application/x-www-form-urlencoded"
request.FILES	# 上传的文件   enctype="multipart/form-data"
request.path_info   # 路径信息  不包含IP和端口  也不包含查询参数
request.body   # 请求体 原始数据
request.COOKIES  # cookies
request.session  # session
request.META   # 请求头的信息

request.get_full_path() # 路径信息  不包含IP和端口 包含查询参数
request.is_ajax()   # 是否是ajax请求 布尔值
```

#### 5.response

```
HttpResponse('字符串')    # 返回字符串
render(request,'模板的文件名'，{})   # 返回一个页面
redirect（地址） # 重定向   响应头 Location： 地址
```

6.远程上传文件

```python

from django.views import  View
from django.utils.decorators import method_decorator

class  Press(View):
    def get(self,request):
        return  render(request,"filename.html")
    def post(self,request):
        print(request.FILES)
        file = request.FILES.get('f1')
        print(file)
        print(file.__dict__)
        with open(file.name,"wb")as f:
            for i in file.chunks():
                f.write(i)
        return render(request,"show.html")

```

### 4.路由

#### 1.URL配置（URLconf）

URL配置(URLconf)就像Django 所支撑网站的目录。它的本质是**URL与要为该URL调用的视图函数之间的映射表**；你就是以这种方式告诉Django，对于客户端发来的某个URL调用哪一段逻辑代码对应执行

```python
from django.conf.urls import url

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r"^register/$",registe),
    url(r"user/register_handle/",register_handle),
    url(r"user/register_exit/", register_exit),
    url(r"login/",login),
    url(r"test/",views.Tiantian.as_view())

]
```

##### 1.简单的路由配置

```python
from django.conf.urls import url

urlpatterns = [
     url(正则表达式, views视图函数，参数，别名),
]
```

- 正则表达式：一个正则表达式字符串
- views视图函数：一个可调用对象，通常为一个视图函数或一个指定视图函数路径的字符串
- 参数：可选的要传递给视图函数的默认参数（字典形式）
- 别名：一个可选的name参数

##### 2.**APPEND_SLASH**

```
# 是否开启URL访问地址后面不为/跳转至带有/的路径的配置项
APPEND_SLASH=True
```

Django settings.py配置文件中默认没有 APPEND_SLASH 这个参数，但 Django 默认这个参数为 APPEND_SLASH = True。 其作用就是自动在网址结尾加'/'。

其效果就是：

我们定义了urls.py：

```python
from django.conf.urls import url
from app01 import views

urlpatterns = [
        url(r'^blog/$', views.blog),
]
```

访问 http://www.example.com/blog 时，默认将网址自动转换为 http://www.example/com/blog/ 。

如果在settings.py中设置了 **APPEND_SLASH=False**，此时我们再请求 http://www.example.com/blog 时就会提示找不到页面。

#### 2.分组

##### 1.无名分组

 (将加括号的正则表达式匹配到的内容当做位置参数自动传递给对应的视图函数)

```
    # 路由    
  url(r'^test/(\d+)/',views.test),  # 匹配一个或多个数字
    # 视图
        def test(request,xxx):
            print(xxx)
            return HttpResponse('test')
```

```python
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^blog/$', views.blogs),  # /blog/
    url(r'^blog/[0-9]{4}/\d{2}/$', views.blog), # /blog/2019/10/
    
]

url(正则表达式的字符串, 视图函数，)

"""
一些请求的例子：

/articles/2005/03/ 请求将匹配列表中的第三个模式。Django 将调用函数views.month_archive(request, '2005', '03')。
/articles/2005/3/ 不匹配任何URL 模式，因为列表中的第三个模式要求月份应该是两个数字。
/articles/2003/ 将匹配列表中的第一个模式不是第二个，因为模式按顺序匹配，第一个会首先测试是否匹配。请像这样自由插入一些特殊的情况来探测匹配的次序。
/articles/2003 不匹配任何一个模式，因为每个模式要求URL 以一个反斜线结尾。
/articles/2003/03/03/ 将匹配最后一个模式。Django 将调用函数views.article_detail(request, '2003', '03', '03')。
   
"""

```

注意：

- 若要从URL 中捕获一个值，只需要在它周围放置一对圆括号。
- 不需要添加一个前导的反斜杠，因为每个URL 都有。例如，应该是`^blog` 而不是 `^/blog`,'/'表示根目录。
- 每个正则表达式前面的'r' 是可选的但是建议加上。它告诉Python 这个字符串是“原始的” —— 字符串中任何字符都不应该转义
- urlpatterns中的元素按照书写顺序从上往下逐一匹配正则表达式，一旦匹配成功则不再继续

##### 2.有名分组

(将加括号的正则表达式匹配到的内容当做关键字参数自动传递给对应的视图函数)

```
    # 路由    
  url(r'^test/(?P<year>\d+)/',views.test),  # 匹配一个或多个数字
    # 视图
  def test(request,year):
    print(year)
    return HttpResponse('test')
```

**注意:** 无名分组和有名分组不能混着用！！！

```
    url(r'^test/(\d+)/(?P<year>\d+)/',views.test)  # 不能混着用
```

**但是** 支持用一类型多个形式匹配。

```
    无名分组多个
        url(r'^test/(\d+)/(\d+)/',views.test),
  有名分组多个
        url(r'^test/(?P<year>\d+)/(?P<xxx>\d+)/',views.test),
```

正则：

正则表达式

​	r''     ^ 开通  $ 结尾 [0-9a-zA-Z]{4}    \d  \w   .   ? 0个或1个     *0个或无数个  + 至少一个 

分组

```
urlpatterns = [

    url(r'^blog/([0-9]{4})/(\d{2})/$', views.blog),

]
```

从URL上捕获参数，将参数按照位置传参传递给视图函数。

```python
import re
ret=re.search('(?P<year>[0-9]{4})/([0-9]{2})','2012/12')
print(ret.group())
print(ret.group(1))
print(ret.group(2))
print(ret.group('year'))
```

上面的示例使用简单的、没有命名的正则表达式组（通过圆括号）来捕获URL 中的值并以位置 参数传递给视图。在更高级的用法中，可以使用命名的正则表达式组来捕获URL 中的值并以关键字 参数传递给视图。

在Python 正则表达式中，命名正则表达式组的语法是**(?P<name>pattern)**，其中`name` 是组的名称，`pattern` 是要匹配的模式。

```python
from django.conf.urls import url

from app01 import views

urlpatterns = [
    url(r'^articles/2003/$', views.special_case_2003),
    url(r'^articles/(?P<year>[0-9]{4})/$', views.year_archive),
    url(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/$', views.month_archive),
    url(r'^articles/(?P<year>[0-9]{4})/(?P<month>[0-9]{2})/(?P<day>[0-9]{2})/$', views.article_detail),
]
#捕获到的数据都是str类型
#视图函数里可以指定默认值
url('blog/$', views.blog),
url('blog/?(?P<num>[0-9]{1})', views.blog),
def blog(request,num=1):
    print(num)
    return HttpResponse('ok')
```

这个实现与前面的示例完全相同，只有一个细微的差别：捕获的值作为关键字参数而不是位置参数传递给视图函数。例如：

```python
"""
/articles/2005/03/ 请求将调用views.month_archive(request, year='2005', month='03')函数，而不是views.month_archive(request, '2005', '03')。
    /articles/2003/03/03/ 请求将调用函数views.article_detail(request, year='2003', month='03', day='03')。

"""
```

在实际应用中，这意味你的URLconf 会更加明晰且不容易产生参数顺序问题的错误 —— 你可以在你的视图函数定义中重新安排参数的顺序。当然，这些好处是以简洁为代价；

##### 3.传递额外的参数给视图函数

URLconfs 具有一个钩子，让你传递一个Python 字典作为额外的参数传递给视图函数。

`django.conf.urls.url()` 可以接收一个可选的第三个参数，它是一个字典，表示想要传递给视图函数的额外关键字参数。

例如：



```
from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^blog/(?P<year>[0-9]{4})/$', views.year_archive, {'foo': 'bar'}),
]
```

在这个例子中，对于/blog/2005/请求，Django 将调用views.year_archive(request, year='2005', foo='bar')。
当传递额外参数的字典中的参数和URL中捕获值的命名关键字参数同名时，函数调用时将使用的是字典中的参数，而不是URL中捕获的参数。

#### 3.路由分发：

##### 1.include

导入模块：

```python
from ddjango.conf.urls improt url , include
```

主路由：：urls

```python
from django.conf.urls import url, include
from django.contrib import admin

from app01 import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),

    url(r'^app01/', include('app01.urls')),
    url(r'^app02/', include('app02.urls')),

    url(r'^file_upload/', views.file_upload),
    url(r'^get_data/', views.get_data),

]

```

在app01里创建一个urls

```python
from django.conf.urls import url


from app01 import views

urlpatterns = [

    url(r'^publisher_list/', views.publisher_list),
    # url(r'^publisher_add/', views.publisher_add),
    url(r'^publisher_add/', views.PublisherAdd.as_view()),
    # url(r'^publisher_add/', view),
    url(r'^publisher_del/(\d+)/', views.publisher_del),  
    url(r'^publisher_edit/', views.publisher_edit),
    

```

#### 4. 反向解析

在使用Django 项目时，一个常见的需求是获得URL的最终形式，以用于嵌入到生成的内容中（视图中和显示给用户的URL等）或者用于处理服务器端的导航（重定向等）。
人们强烈希望不要硬编码这些URL（费力、不可扩展且容易产生错误）或者设计一种与URLconf 毫不相关的专门的URL 生成机制，因为这样容易导致一定程度上产生过期的URL。
换句话讲，需要的是一个DRY 机制。除了其它有点，它还允许设计的URL 可以自动更新而不用遍历项目的源代码来搜索并替换过期的URL。
获取一个URL 最开始想到的信息是处理它视图的标识（例如名字），查找正确的URL 的其它必要的信息有视图参数的类型（位置参数、关键字参数）和值。
Django 提供一个办法是让URL 映射是URL 设计唯一的地方。你填充你的URLconf，然后可以双向使用它：

- 根据用户/浏览器发起的URL 请求，它调用正确的Django 视图，并从URL 中提取它的参数需要的值。
- 根据Django 视图的标识和将要传递给它的参数的值，获取与之关联的URL。

第一种方式是我们在前面的章节中一直讨论的用法。第二种方式叫做反向解析URL、反向URL 匹配、反向URL 查询或者简单的URL 反查。
在需要URL 的地方，对于不同层级，Django 提供不同的工具用于URL 反查：

- 在模板中：使用url模板标签。
- 在Python 代码中：使用django.core.urlresolvers.reverse() 函数。
- 在更高层的与处理Django 模型实例相关的代码中：使用get_absolute_url() 方法。

上面说了一大堆，你可能并没有看懂。（那是官方文档的生硬翻译）。

咱们简单来说就是可以给我们的URL匹配规则起个名字，一个URL匹配模式起一个名字。

这样我们以后就不需要写死URL代码了，只需要通过名字来调用当前的URL。

举个简单的例子：

```
url(r'^home', views.home, name='home'),  # 给我的url匹配模式起名为 home
url(r'^index/(\d*)', views.index, name='index'),  # 给我的url匹配模式起名为index
```

这样：

在模板里面可以这样引用：

```
{% url 'home' %}
```

在views函数中可以这样引用：

```python
from django.urls import reverse

reverse("index", args=("2018", ))
```

反向解析：

根据名字动态获取到对应的路径：

路由

```
    from django.shortcuts import reverse
    
    url(r'^index6668888/$',views.index,name='index')
    # 可以给每一个路由与视图函数对应关系起一个名字
    # 这个名字能够唯一标识出对应的路径
    # 注意这个名字不能重复是唯一的
```

前端

```
    {% url 'index' %}
    {% url '你给路由与视图函数对应关系起的别名' %}
```

后端使用

```
    reverse('index')
    reverse('你给路由与视图函数对应关系起的别名')
```

##### 1.静态路由：

url之name 详解： url的命名

name 的出现是为了解决当页面很多时，如若出现更改名字时，会随之更改很多与之相关的名字

注意的是name是全局的，你整个urlpatterns里只能一个唯一的name，这个道理应该好理解，就像网站的地址也是唯一性的。

```
url(r'^publisher_list/', views.publisher_list, name='publisher_list'),
```

URL反向解析

模板

```
{% url 'publisher_list' %}    ——
》  解析生成完整的URL路径  '/app01/publisher_list/'
```

py文件

```
from django.shortcuts import render, redirect, HttpResponse, reverse
from django.urls import reverse

reverse('publisher_list')   ——》  '/app01/publisher_list/'
```

###### 1.1无名分组：

URL的命名

```
 url(r'^publisher_del/(\d+)/', views.publisher_del,name='publisher_del'),
```

URL反向解析

模板

```
{% url 'publisher_del' 1  %}    ——》  解析生成完整的URL路径  '/app01/publisher_del/1/'
```

py文件

```
n'xfrom django.shortcuts import render, redirect, HttpResponse, reverse
from django.urls import reverse

reverse('pub_del',args=(1,))   ——》  '/app01/publisher_del/1/'
```

###### 1.2有名分组

URL的命名

```
 url(r'^publisher_del/(?P<pk>\d+)/', views.publisher_del,name='publisher_del'),
```

URL反向解析

模板

```
{% url 'publisher_del' 1  %}    ——》  解析生成完整的URL路径  '/app01/publisher_del/1/'
{% url 'publisher_del' pk=1  %}    ——》  解析生成完整的URL路径  '/app01/publisher_del/1/'
```

py文件

```
from django.shortcuts import render, redirect, HttpResponse, reverse
from django.urls import reverse

reverse('pub_del',args=(1,))   ——》  '/app01/publisher_del/1/'
reverse('pub_del',kwargs={'pk':1})   ——》  '/app01/publisher_del/1/'
```

#### 5.命名空间：

协同开发时，比如app01下面有个home路由，app02下面有个home路由，当去在后端进行反向解析时，会发现，解析出来的是，urlpattern中排在后面的路由，因为后面的把之前的覆盖了。

而命名空间相对于两个app01和app02的作用域隔开，使用反向解析时，可以准确解析出url地址

###### 1.namespace

```
urlpatterns = [

    url(r'^app01/', include('app01.urls', namespace='app01')),  # home   name=home
    url(r'^app02/', include('app02.urls', namespace='app02')),  # home   name=home

]

```

反向解析生成URL

{%  url  'namespace:name'  % }

reverse( 'namespace:name'  )

#### **6.注意：*

为了完成上面例子中的URL 反查，你将需要使用命名的URL 模式。URL 的名称使用的字符串可以包含任何你喜欢的字符。不只限制在合法的Python 名称。

当命名你的URL 模式时，请确保使用的名称不会与其它应用中名称冲突。如果你的URL 模式叫做`comment`，而另外一个应用中也有一个同样的名称，当你在模板中使用这个名称的时候不能保证将插入哪个URL。

在URL 名称中加上一个前缀，比如应用的名称，将减少冲突的可能。我们建议使用`myapp-comment` 而不是`comment`。

### 5.ORM

#### 1.ORM概念

对象关系映射模式是一种为了解决面向对象与关系数据库存在的互不匹配的现象的技术。

简单的说，ORM是通过使用描述对象和数据库之间映射的元数据，将程序中的对象自动持久化到关系数据库中。

ORM在业务逻辑层和数据库层之间充当了桥梁的作用。

##### 1.ORM由来

让我们从O/R开始。字母O起源于"对象"(Object)，而R则来自于"关系"(Relational)。

几乎所有的软件开发过程中都会涉及到对象和关系数据库。在用户层面和业务逻辑层面，我们是面向对象的。当对象的信息发生变化的时候，我们就需要把对象的信息保存在关系数据库中。

按照之前的方式来进行开发就会出现程序员会在自己的业务逻辑代码中夹杂很多SQL语句用来增加、读取、修改、删除相关数据，而这些代码通常都是极其相似或者重复的。

##### 2.ORM的优势

ORM解决的主要问题是对象和关系的映射。它通常将一个类和一张表一一对应，类的每个实例对应表中的一条记录，类的每个属性对应表中的每个字段。 

ORM提供了对数据库的映射，不用直接编写SQL代码，只需操作对象就能对数据库操作数据。

让软件开发人员专注于业务逻辑的处理，提高了开发效率。

##### 3.ORM的劣势

ORM的缺点是会在一定程度上牺牲程序的执行效率。

ORM的操作是有限的，也就是ORM定义好的操作是可以完成的，一些复杂的查询操作是完成不了。

ORM用多了SQL语句就不会写了，关系数据库相关技能退化...

##### 4.ORM总结

ORM只是一种工具，工具确实能解决一些重复，简单的劳动。这是不可否认的。

但我们不能指望某个工具能一劳永逸地解决所有问题，一些特殊问题还是需要特殊处理的。

但是在整个软件开发过程中需要特殊处理的情况应该都是很少的，否则所谓的工具也就失去了它存在的意义

#### 2.Django中的ORM

1. 在Django项目的settings.py文件中，配置数据库连接信息：

```python
`DATABASES ``=` `{``    ``"default"``: {``        ``"ENGINE"``: ``"django.db.backends.mysql"``,``        ``"NAME"``: ``"你的数据库名称"``,  ``# 需要自己手动创建数据库``        ``"USER"``: ``"数据库用户名"``,``        ``"PASSWORD"``: ``"数据库密码"``,``        ``"HOST"``: ``"数据库IP"``,``        ``"POST"``: ``3306``    ``}``}`
```

2. 在与Django项目同名的目录下的__init__.py文件中写如下代码，告诉Django使用pymysql模块连接MySQL数据库:

```python
`import` `pymysql` `pymysql.install_as_MySQLdb()`
```

注：数据库迁移的时候出现一个警告

```
WARNINGS: 
?: (mysql.W002) MySQL Strict Mode is not set for database connection 'default'
HINT: MySQL's Strict Mode fixes many data integrity problems in MySQL, such as data truncation upon insertion, by escalating warnings into errors. It is strongly recommended you activate it.
```

在配置中多加一个OPTIONS参数：[Django官网解释](https://docs.djangoproject.com/en/1.11/ref/databases/#setting-sql-mode)

```
 'OPTIONS': {
    'init_command': "SET sql_mode='STRICT_TRANS_TABLES'"},
```

##### 1.Model

在Django中model是你数据的单一、明确的信息来源。它包含了你存储的数据的重要字段和行为。通常，一个模型（model）映射到一个数据库表。

基本情况：

- 每个模型都是一个Python类，它是django.db.models.Model的子类。
- 模型的每个属性都代表一个数据库字段。
- 综上所述，Django为您提供了一个自动生成的数据库访问API，详询[官方文档链接](https://docs.djangoproject.com/en/1.11/topics/db/queries/)。

![1572755116779](django02.assets/1572755116779.png)

##### 2.快速入门

下面这个例子定义了一个 **Person** 模型，包含 **first_name** 和 **last_name**。

```python
from django.db import models
 
class Person(models.Model):
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
```

**first_name** 和 **last_name** 是模型的字段。每个字段被指定为一个类属性，每个属性映射到一个数据库列。

上面的 **Person** 模型将会像这样创建一个数据库表：

```python
CREATE TABLE myapp_person (
    "id" serial NOT NULL PRIMARY KEY,
    "first_name" varchar(30) NOT NULL,
    "last_name" varchar(30) NOT NULL
);
```

一些说明：

- 表myapp_person的名称是自动生成的，如果你要自定义表名，需要在model的Meta类中指定 db_table 参数，强烈建议使用小写表名，特别是使用MySQL作为数据库时。
- id字段是自动添加的，如果你想要指定自定义主键，只需在其中一个字段中指定 primary_key=True 即可。如果Django发现你已经明确地设置了Field.primary_key，它将不会添加自动ID列。
- 本示例中的CREATE TABLE SQL使用PostgreSQL语法进行格式化，但值得注意的是，Django会根据配置文件中指定的数据库类型来生成相应的SQL语句。
- Django支持MySQL5.5及更高版本。

##### 3.字段

###### 1.**常用字段** 

**AutoField**

自增的整形字段，必填参数primary_key=True，则成为数据库的主键。无该字段时，django自动创建。

一个model不能有两个AutoField字段。

**IntegerField**

一个整数类型。数值的范围是 -2147483648 ~ 2147483647。

**CharField**

字符类型，必须提供max_length参数。max_length表示字符的长度。

**DateField**

日期类型，日期格式为YYYY-MM-DD，相当于Python中的datetime.date的实例。

参数：

- auto_now：每次修改时修改为当前日期时间。
- auto_now_add：新创建对象时自动添加当前日期时间。

auto_now和auto_now_add和default参数是互斥的，不能同时设置。

**DatetimeField**

日期时间字段，格式为YYYY-MM-DD HH:MM[:ss[.uuuuuu]][TZ]，相当于Python中的datetime.datetime的实例。

字段类型，详情可点击查询[官网](https://docs.djangoproject.com/en/1.11/ref/models/fields/#field-types)。

```python
AutoField(Field)
        - int自增列，必须填入参数 primary_key=True

    BigAutoField(AutoField)
        - bigint自增列，必须填入参数 primary_key=True

        注：当model中如果没有自增列，则自动会创建一个列名为id的列
        from django.db import models

        class UserInfo(models.Model):
            # 自动创建一个列名为id的且为自增的整数列
            username = models.CharField(max_length=32)

        class Group(models.Model):
            # 自定义自增列
            nid = models.AutoField(primary_key=True)
            name = models.CharField(max_length=32)

    SmallIntegerField(IntegerField):
        - 小整数 -32768 ～ 32767

    PositiveSmallIntegerField(PositiveIntegerRelDbTypeMixin, IntegerField)
        - 正小整数 0 ～ 32767

    IntegerField(Field)
        - 整数列(有符号的) -2147483648 ～ 2147483647

    PositiveIntegerField(PositiveIntegerRelDbTypeMixin, IntegerField)
        - 正整数 0 ～ 2147483647

    BigIntegerField(IntegerField):
        - 长整型(有符号的) -9223372036854775808 ～ 9223372036854775807

    BooleanField(Field)
        - 布尔值类型

    NullBooleanField(Field):
        - 可以为空的布尔值

    CharField(Field)
        - 字符类型
        - 必须提供max_length参数， max_length表示字符长度

    TextField(Field)
        - 文本类型

    EmailField(CharField)：
        - 字符串类型，Django Admin以及ModelForm中提供验证机制

    IPAddressField(Field)
        - 字符串类型，Django Admin以及ModelForm中提供验证 IPV4 机制

    GenericIPAddressField(Field)
        - 字符串类型，Django Admin以及ModelForm中提供验证 Ipv4和Ipv6
        - 参数：
            protocol，用于指定Ipv4或Ipv6， 'both',"ipv4","ipv6"
            unpack_ipv4， 如果指定为True，则输入::ffff:192.0.2.1时候，可解析为192.0.2.1，开启此功能，需要protocol="both"

    URLField(CharField)
        - 字符串类型，Django Admin以及ModelForm中提供验证 URL

    SlugField(CharField)
        - 字符串类型，Django Admin以及ModelForm中提供验证支持 字母、数字、下划线、连接符（减号）

    CommaSeparatedIntegerField(CharField)
        - 字符串类型，格式必须为逗号分割的数字

    UUIDField(Field)
        - 字符串类型，Django Admin以及ModelForm中提供对UUID格式的验证

    FilePathField(Field)
        - 字符串，Django Admin以及ModelForm中提供读取文件夹下文件的功能
        - 参数：
                path,                      文件夹路径
                match=None,                正则匹配
                recursive=False,           递归下面的文件夹
                allow_files=True,          允许文件
                allow_folders=False,       允许文件夹

    FileField(Field)
        - 字符串，路径保存在数据库，文件上传到指定目录
        - 参数：
            upload_to = ""      上传文件的保存路径
            storage = None      存储组件，默认django.core.files.storage.FileSystemStorage

    ImageField(FileField)
        - 字符串，路径保存在数据库，文件上传到指定目录
        - 参数：
            upload_to = ""      上传文件的保存路径
            storage = None      存储组件，默认django.core.files.storage.FileSystemStorage
            width_field=None,   上传图片的高度保存的数据库字段名（字符串）
            height_field=None   上传图片的宽度保存的数据库字段名（字符串）

    DateTimeField(DateField)
        - 日期+时间格式 YYYY-MM-DD HH:MM[:ss[.uuuuuu]][TZ]

    DateField(DateTimeCheckMixin, Field)
        - 日期格式      YYYY-MM-DD

    TimeField(DateTimeCheckMixin, Field)
        - 时间格式      HH:MM[:ss[.uuuuuu]]

    DurationField(Field)
        - 长整数，时间间隔，数据库中按照bigint存储，ORM中获取的值为datetime.timedelta类型

    FloatField(Field)
        - 浮点型

    DecimalField(Field)
        - 10进制小数
        - 参数：
            max_digits，小数总长度
            decimal_places，小数位长度

    BinaryField(Field)
        - 二进制类型
```

###### 2.自定义字段

自定义一个二进制字段，以及Django字段与数据库字段类型的对应关系。

```python
class UnsignedIntegerField(models.IntegerField):
    def db_type(self, connection):
        return 'integer UNSIGNED'

# PS: 返回值为字段在数据库中的属性。
# Django字段与数据库字段类型对应关系如下：
    'AutoField': 'integer AUTO_INCREMENT',
    'BigAutoField': 'bigint AUTO_INCREMENT',
    'BinaryField': 'longblob',
    'BooleanField': 'bool',
    'CharField': 'varchar(%(max_length)s)',
    'CommaSeparatedIntegerField': 'varchar(%(max_length)s)',
    'DateField': 'date',
    'DateTimeField': 'datetime',
    'DecimalField': 'numeric(%(max_digits)s, %(decimal_places)s)',
    'DurationField': 'bigint',
    'FileField': 'varchar(%(max_length)s)',
    'FilePathField': 'varchar(%(max_length)s)',
    'FloatField': 'double precision',
    'IntegerField': 'integer',
    'BigIntegerField': 'bigint',
    'IPAddressField': 'char(15)',
    'GenericIPAddressField': 'char(39)',
    'NullBooleanField': 'bool',
    'OneToOneField': 'integer',
    'PositiveIntegerField': 'integer UNSIGNED',
    'PositiveSmallIntegerField': 'smallint UNSIGNED',
    'SlugField': 'varchar(%(max_length)s)',
    'SmallIntegerField': 'smallint',
    'TextField': 'longtext',
    'TimeField': 'time',
    'UUIDField': 'char(32)',
```

自定义一个char类型字段：

```python
class MyCharField(models.Field):
    """
    自定义的char类型的字段类
    """
    def __init__(self, max_length, *args, **kwargs):
        self.max_length = max_length
        super(MyCharField, self).__init__(max_length=max_length, *args, **kwargs)
 
    def db_type(self, connection):
        """
        限定生成数据库表的字段类型为char，长度为max_length指定的值
        """
        return 'char(%s)' % self.max_length
```

使用自定义char类型字段：

```python
class Class(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=25)
    # 使用自定义的char类型的字段
    cname = MyCharField(max_length=25)
```

##### 3.字段参数

字段参数，详情可点击查看[官网](https://docs.djangoproject.com/en/1.11/ref/models/fields/#field-options)。

```python
null                数据库中字段是否可以为空
    db_column           数据库中字段的列名
    default             数据库中字段的默认值
    primary_key         数据库中字段是否为主键
    db_index            数据库中字段是否可以建立索引
    unique              数据库中字段是否可以建立唯一索引
    unique_for_date     数据库中字段【日期】部分是否可以建立唯一索引
    unique_for_month    数据库中字段【月】部分是否可以建立唯一索引
    unique_for_year     数据库中字段【年】部分是否可以建立唯一索引
 
    verbose_name        Admin中显示的字段名称
    blank               Admin中是否允许用户输入为空
    editable            Admin中是否可以编辑
    help_text           Admin中该字段的提示信息
    choices             Admin中显示选择框的内容，用不变动的数据放在内存中从而避免跨表操作
                        如：gf = models.IntegerField(choices=[(0, '何穗'),(1, '大表姐'),],default=1)
 
    error_messages      自定义错误信息（字典类型），从而定制想要显示的错误信息；
                        字典健：null, blank, invalid, invalid_choice, unique, and unique_for_date
                        如：{'null': "不能为空.", 'invalid': '格式错误'}
 
    validators          自定义错误验证（列表类型），从而定制想要的验证规则
                        from django.core.validators import RegexValidator
                        from django.core.validators import EmailValidator,URLValidator,DecimalValidator,\
                        MaxLengthValidator,MinLengthValidator,MaxValueValidator,MinValueValidator
                        如：
                            test = models.CharField(
                                max_length=32,
                                error_messages={
                                    'c1': '优先错信息1',
                                    'c2': '优先错信息2',
                                    'c3': '优先错信息3',
                                },
                                validators=[
                                    RegexValidator(regex='root_\d+', message='错误了', code='c1'),
                                    RegexValidator(regex='root_112233\d+', message='又错误了', code='c2'),
                                    EmailValidator(message='又错误了', code='c3'), ]
                            )
 
字段参数
```

##### 4.Model Meta参数

这个不是很常用，如果你有特殊需要可以使用。详情点击查看[官网](https://docs.djangoproject.com/en/1.11/ref/models/options/#model-meta-options)。

```python
class UserInfo(models.Model):
    nid = models.AutoField(primary_key=True)
    username = models.CharField(max_length=32)
 
    class Meta:
        # 数据库中生成的表名称 默认 app名称 + 下划线 + 类名
        db_table = "table_name"
 
        # admin中显示的表名称
        verbose_name = '个人信息'
 
        # verbose_name加s
        verbose_name_plural = '所有用户信息'
 

        # 联合索引 
        index_together = [
            ("pub_date", "deadline"),   # 应为两个存在的字段
        ]
 
        # 联合唯一索引
        unique_together = (("driver", "restaurant"),)   # 应为两个存在的字段
```

##### 5.多表关系和参数

```python
ForeignKey(ForeignObject) # ForeignObject(RelatedField)
    to,                 # 要进行关联的表名
    to_field=None,      # 要关联的表中的字段名称
    on_delete=None,     # 当删除关联表中的数据时，当前表与其关联的行的行为
                        - models.CASCADE，删除关联数据，与之关联也删除
                        - models.DO_NOTHING，删除关联数据，引发错误IntegrityError
                        - models.PROTECT，删除关联数据，引发错误ProtectedError
                        - models.SET_NULL，删除关联数据，与之关联的值设置为null（前提FK字段需要设置为可空）
                        - models.SET_DEFAULT，删除关联数据，与之关联的值设置为默认值（前提FK字段需要设置默认值）
                        - models.SET，删除关联数据，
                               a. 与之关联的值设置为指定值，设置：models.SET(值)
                               b. 与之关联的值设置为可执行对象的返回值，设置：models.SET(可执行对象)
 
                                    def func():
                                        return 10
 
                                    class MyModel(models.Model):
                                        user = models.ForeignKey(
                                            to="User",
                                            to_field="id"
                                            on_delete=models.SET(func),)
    related_name=None,          # 反向操作时，使用的字段名，用于代替 【表名_set】 如： obj.表名_set.all()
    related_query_name=None,    # 反向操作时，使用的连接前缀，用于替换【表名】     如： models.UserGroup.objects.filter(表名__字段名=1).values('表名__字段名')
    limit_choices_to=None,      # 在Admin或ModelForm中显示关联数据时，提供的条件：
                                # 如：
                        - limit_choices_to={'nid__gt': 5}
                        - limit_choices_to=lambda : {'nid__gt': 5}
 
                        from django.db.models import Q
                        - limit_choices_to=Q(nid__gt=10)
                        - limit_choices_to=Q(nid=8) | Q(nid__gt=10)
                        - limit_choices_to=lambda : Q(Q(nid=8) | Q(nid__gt=10)) & Q(caption='root')
    db_constraint=True          # 是否在数据库中创建外键约束
    parent_link=False           # 在Admin中是否显示关联数据
 
 
OneToOneField(ForeignKey)
    to,                 # 要进行关联的表名
    to_field=None       # 要关联的表中的字段名称
    on_delete=None,     # 当删除关联表中的数据时，当前表与其关联的行的行为
 
                        ###### 对于一对一 ######
                        # 1. 一对一其实就是 一对多 + 唯一索引
                        # 2.当两个类之间有继承关系时，默认会创建一个一对一字段
                        # 如下会在A表中额外增加一个c_ptr_id列且唯一：
                                class C(models.Model):
                                    nid = models.AutoField(primary_key=True)
                                    part = models.CharField(max_length=12)
 
                                class A(C):
                                    id = models.AutoField(primary_key=True)
                                    code = models.CharField(max_length=1)
 
ManyToManyField(RelatedField)
    to,                         # 要进行关联的表名
    related_name=None,          # 反向操作时，使用的字段名，用于代替 【表名_set】 如： obj.表名_set.all()
    related_query_name=None,    # 反向操作时，使用的连接前缀，用于替换【表名】     如： models.UserGroup.objects.filter(表名__字段名=1).values('表名__字段名')
    limit_choices_to=None,      # 在Admin或ModelForm中显示关联数据时，提供的条件：
                                # 如：
                                    - limit_choices_to={'nid__gt': 5}
                                    - limit_choices_to=lambda : {'nid__gt': 5}
 
                                    from django.db.models import Q
                                    - limit_choices_to=Q(nid__gt=10)
                                    - limit_choices_to=Q(nid=8) | Q(nid__gt=10)
                                    - limit_choices_to=lambda : Q(Q(nid=8) | Q(nid__gt=10)) & Q(caption='root')
    symmetrical=None,           # 仅用于多对多自关联时，symmetrical用于指定内部是否创建反向操作的字段
                                # 做如下操作时，不同的symmetrical会有不同的可选字段
                                    models.BB.objects.filter(...)
 
                                    # 可选字段有：code, id, m1
                                        class BB(models.Model):
 
                                        code = models.CharField(max_length=12)
                                        m1 = models.ManyToManyField('self',symmetrical=True)
 
                                    # 可选字段有: bb, code, id, m1
                                        class BB(models.Model):
 
                                        code = models.CharField(max_length=12)
                                        m1 = models.ManyToManyField('self',symmetrical=False)
 
    through=None,               # 自定义第三张表时，使用字段用于指定关系表
    through_fields=None,        # 自定义第三张表时，使用字段用于指定关系表中那些字段做多对多关系表
                                    from django.db import models
 
                                    class Person(models.Model):
                                        name = models.CharField(max_length=50)
 
                                    class Group(models.Model):
                                        name = models.CharField(max_length=128)
                                        members = models.ManyToManyField(
                                            Person,
                                            through='Membership',
                                            through_fields=('group', 'person'),
                                        )
 
                                    class Membership(models.Model):
                                        group = models.ForeignKey(Group, on_delete=models.CASCADE)
                                        person = models.ForeignKey(Person, on_delete=models.CASCADE)
                                        inviter = models.ForeignKey(
                                            Person,
                                            on_delete=models.CASCADE,
                                            related_name="membership_invites",
                                        )
                                        invite_reason = models.CharField(max_length=64)
    db_constraint=True,         # 是否在数据库中创建外键约束
    db_table=None,              # 默认创建第三张表时，数据库中表的名称
```

##### 6.ORM操作

###### 1.基本操作

```python
# 增
models.Tb1.objects.create(c1='xx', c2='oo')   # 增加一条数据，可以接受字典类型数据 **kwargs
obj = models.Tb1(c1='xx', c2='oo')
obj.save()
 
 
# 查
models.Tb1.objects.get(id=123)  # 获取单条数据，不存在则报错（不建议）
models.Tb1.objects.all()  # 获取全部
models.Tb1.objects.filter(name='seven')  # 获取指定条件的数据
models.Tb1.objects.exclude(name='seven')  # 去除指定条件的数据
 
 
# 删
# models.Tb1.objects.filter(name='seven').delete()  # 删除指定条件的数据
 
 
# 改
models.Tb1.objects.filter(name='seven').update(gender='0')   # 将指定条件的数据更新，均支持 **kwargs
obj = models.Tb1.objects.get(id=1)
obj.c1 = '111'
obj.save()   # 修改单条数据
```

###### 2.进阶操作

```python
# 获取个数
#
# models.Tb1.objects.filter(name='seven').count()

# 大于，小于
#
# models.Tb1.objects.filter(id__gt=1)              # 获取id大于1的值
# models.Tb1.objects.filter(id__gte=1)              # 获取id大于等于1的值
# models.Tb1.objects.filter(id__lt=10)             # 获取id小于10的值
# models.Tb1.objects.filter(id__lte=10)             # 获取id小于10的值
# models.Tb1.objects.filter(id__lt=10, id__gt=1)   # 获取id大于1 且 小于10的值

# 成员判断in
#
# models.Tb1.objects.filter(id__in=[11, 22, 33])   # 获取id等于11、22、33的数据
# models.Tb1.objects.exclude(id__in=[11, 22, 33])  # not in

# 是否为空 isnull
# Entry.objects.filter(pub_date__isnull=True)

# 包括contains
#
# models.Tb1.objects.filter(name__contains="ven")
# models.Tb1.objects.filter(name__icontains="ven") # icontains大小写不敏感
# models.Tb1.objects.exclude(name__icontains="ven")

# 范围range
#
# models.Tb1.objects.filter(id__range=[1, 2])   # 范围bettwen and

# 其他类似
#
# startswith，istartswith, endswith, iendswith,

# 排序order by
#
# models.Tb1.objects.filter(name='seven').order_by('id')    # asc
# models.Tb1.objects.filter(name='seven').order_by('-id')   # desc

# 分组group by
#
# from django.db.models import Count, Min, Max, Sum
# models.Tb1.objects.filter(c1=1).values('id').annotate(c=Count('num'))
# SELECT "app01_tb1"."id", COUNT("app01_tb1"."num") AS "c" FROM "app01_tb1" WHERE "app01_tb1"."c1" = 1 GROUP BY "app01_tb1"."id"

# limit 、offset
#
# models.Tb1.objects.all()[10:20]

# regex正则匹配，iregex 不区分大小写
#
# Entry.objects.get(title__regex=r'^(An?|The) +')
# Entry.objects.get(title__iregex=r'^(an?|the) +')

# date
#
# Entry.objects.filter(pub_date__date=datetime.date(2005, 1, 1))
# Entry.objects.filter(pub_date__date__gt=datetime.date(2005, 1, 1))

# year
#
# Entry.objects.filter(pub_date__year=2005)
# Entry.objects.filter(pub_date__year__gte=2005)

# month
#
# Entry.objects.filter(pub_date__month=12)
# Entry.objects.filter(pub_date__month__gte=6)

# day
#
# Entry.objects.filter(pub_date__day=3)
# Entry.objects.filter(pub_date__day__gte=3)

# week_day
#
# Entry.objects.filter(pub_date__week_day=2)
# Entry.objects.filter(pub_date__week_day__gte=2)

# hour
#
# Event.objects.filter(timestamp__hour=23)
# Event.objects.filter(time__hour=5)
# Event.objects.filter(timestamp__hour__gte=12)

# minute
#
# Event.objects.filter(timestamp__minute=29)
# Event.objects.filter(time__minute=46)
# Event.objects.filter(timestamp__minute__gte=29)

# second
#
# Event.objects.filter(timestamp__second=31)
# Event.objects.filter(time__second=2)
# Event.objects.filter(timestamp__second__gte=31)
```

##### 7.总结：

###### 1.常用的字段

```
AutoField         自增  primary_key=True主键
IntegerField	  整形 -21亿  - 21亿 
BooleanField   NullBooleanField     布尔值  0 1
CharField       字符串   
TextField       文本类型
DateTimeField  DateField TimeField
FloatField      浮点型
DecimalField	十进制小数
```

###### 2.字段参数

```
null=True     数据库中该字段可以为空
blank=True    用户输入可以为空
default       默认值
db_index=True  索引
unique         唯一约束
verbose_name   显示的名称
choices        可选择的参数
```

**返回QuerySet对象的方法有**

- all()

- filter()

- exclude()
- order_by()
- reverse()
- distinct()

特殊的QuerySet

- values()       返回一个可迭代的字典序列
- values_list() 返回一个可迭代的元祖序列

返回具体对象的**

- get()
- first()
- last()

返回布尔值的方法有：**

- exists()

返回数字的方法有**

- count()

###### 3.使用admin的步骤：

1. 创建一个超级用户

    python manage.py createsuperuser

    输入用户名  和 秘密

2. 在app下的admin.py中注册model

    ```
    from django.contrib import admin
    from app01 import models
    # Register your models here.
    admin.site.register(models.Person)
    
    ```

3. 地址栏输入/admin/

###### 4.必知必会13条

```python 
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "about_orm.settings")
import django

django.setup()

from app01 import models

# all()   获取所有的数据  QuerySet  对象列表
ret = models.Person.objects.all()

# get()   获取一个对象  对象  不存在或者多个就报错
# ret = models.Person.objects.get(name='alexdsb')

# filter()   获取满足条件的所有对象  QuerySet  对象列表
ret = models.Person.objects.filter(name='alexdsb')

# exclude()  获取不满足条件的所有对象   QuerySet  对象列表
ret = models.Person.objects.exclude(name='alexdsb')

# values  QuerySet   [ {} ]
# values()  不写参数  获取所有字段的字段名和值
# values('name','age')  指定字段 获取指定字段的字段名和值
ret = models.Person.objects.values('name', 'age')
# for i in ret:
#     print(i,type(i))

# values_list  QuerySet   [ () ]
# values_list()  不写参数  获取所有字段的值
# values_list('name','age')  指定字段 获取指定字段的值

ret = models.Person.objects.values_list('age', 'name')

# for i in ret:
#     print(i, type(i))

# order_by   排序  默认升序   降序 字段名前加-   支持多个字段
ret = models.Person.objects.all().order_by('-age', 'pk')


# reverse  对已经排序的结果进行反转
ret = models.Person.objects.all().order_by('pk')
ret = models.Person.objects.all().order_by('pk').reverse()

# distinct mysql不支持按字段去重
ret = models.Person.objects.all().distinct()

ret = models.Person.objects.values('name','age').distinct()

# count()  计数
ret = models.Person.objects.all().count()
ret = models.Person.objects.filter(name='alexdsb').count()

# first  取第一个元素  取不到是None
ret = models.Person.objects.filter(name='xxxx').first()

# last  取最后一个元素
ret = models.Person.objects.values().first()

# exists  是否存在  存在是True
ret = models.Person.objects.filter(name='xx').exists()
print(ret)


"""
返回对象列表  QuerySet
all()  
filter() 
exclude()
values()    [ {},{} ]
values_list()    [ (),() ]
order_by()
reverse() 
distinct()


返回对象
get
first
last

返回数字
count

返回布尔值
exists() 
"""

```

###### 5.单表的双下划线

```python
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "about_orm.settings")
import django

django.setup()

from app01 import models

ret = models.Person.objects.filter(pk__gt=3)  # gt  greater than 大于
ret = models.Person.objects.filter(pk__lt=3)  # lt  less than   小于

ret = models.Person.objects.filter(pk__gte=3)  # gt  greater than equal  大于等于
ret = models.Person.objects.filter(pk__lte=3)  # lt  less than equal    小于等于

ret = models.Person.objects.filter(pk__range=[1, 4])  # 范围
ret = models.Person.objects.filter(pk__in=[1, 4])   # 成员判断
ret = models.Person.objects.filter(name__in=['alexdsb','xx'])

ret = models.Person.objects.filter(name__contains='x')   # contains 包含  like
ret = models.Person.objects.filter(name__icontains='X')   # ignore contains 忽略大小写

ret = models.Person.objects.filter(name__startswith='X')   # 以什么开头
ret = models.Person.objects.filter(name__istartswith='X')   # 以什么开头

ret = models.Person.objects.filter(name__endswith='dsb')   # 以什么开头
ret = models.Person.objects.filter(name__iendswith='DSB')   # 以什么开头


ret = models.Person.objects.filter(phone__isnull=False)   # __isnull=False  不为null

ret = models.Person.objects.filter(birth__year='2020')
ret = models.Person.objects.filter(birth__contains='2020-11-02')
print(ret)

```

###### 6.Foreignkey 操作

正向查找：

对象查找（跨表）

语法：

**对象****.****关联字段****.****字段** 

示例：

```python
book_obj = models.Book.objects.first()  # 第一本书对象
print(book_obj.publisher)  # 得到这本书关联的出版社对象
print(book_obj.publisher.name)  # 得到出版社对象的名称
```

字段查找（跨表）

语法：

**关联字段****__****字段**

示例：

```python
print(models.Book.objects.values_list("publisher__name"))
```

反向操作

对象查找

语法：

**obj.表名_set**

示例：

```python
publisher_obj = models.Publisher.objects.first()  # 找到第一个出版社对象
books = publisher_obj.book_set.all()  # 找到第一个出版社出版的所有书
titles = books.values_list("title")  # 找到第一个出版社出版的所有书的书名
```

字段查找

语法：

**表名__字段**

示例：

```python
titles = models.Publisher.objects.values_list("book__title")
```

反向查找时，可以采用related_name 替换掉表名_set的方法:

```python
class Books(models.Model):
    name = models.CharField(max_length=20)
    lby = models.ForeignKey('librarylis',related_name='bs',related_query_name='bt')
    def __str__(self):
        return  self.name

ret  = models.librarylis.objects.get(pk=8)
print(ret.bs.all())
"""
<QuerySet [<Books: 哇哈哈>, <Books: linux>, <Books: go语言>, <Books: C语言深入剖析>]>
"""
```

related_query_name:

```python
class Books(models.Model):
    name = models.CharField(max_length=20)
    lby = models.ForeignKey('librarylis',related_name='bs',related_query_name='bt')
    def __str__(self):
        return  self.name
  
print(models.librarylis.objects.filter(bt__id=8))

"""
<QuerySet [<librarylis: 苏教出版社>]>
"""
```

当related_name 和 related_query_name 同时存在存在时，使用related_query_name 进行filter进行过滤

related_name 只能用于反向查找。

values返回是一个字典

values_list 返回是一个元祖

```python
ret  = models.librarylis.objects.get(pk=8)
print(ret.bs.all())
print(ret.bs.all().values())
print(ret.bs.all().values_list())
"""

<QuerySet [<Books: 哇哈哈>, <Books: linux>, <Books: go语言>, <Books: C语言深入剖析>]>


<QuerySet [{'id': 7, 'name': '哇哈哈', 'lby_id': 8}, {'id': 8, 'name': 'linux', 'lby_id': 8}, {'id': 9, 'name': 'go语言', 'lby_id': 8}, {'id': 10, 'name': 'C语言深入剖析', 'lby_id': 8}]>


<QuerySet [(7, '哇哈哈', 8), (8, 'linux', 8), (9, 'go语言', 8), (10, 'C语言深入剖析', 8)]>

"""

```

###### 7.ManytoManyField

1.class RelatedManager

"关联管理器"是在一对多或者多对多的关联上下文中使用的管理器。

它存在于下面两种情况：

1. 外键关系的反向查询
2. 多对多关联关系

简单来说就是当 点后面的对象 可能存在多个的时候就可以使用以下的方法。

2.方法

**create()**

创建一个新的对象，保存对象，并将它添加到关联对象集之中，返回新创建的对象。

```python
models:
  
class librarylis(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=32)
    addr = models.CharField(max_length=32)
    phone = models.CharField(max_length=11)
    def __str__(self):
        return self.name

class Books(models.Model):
    name = models.CharField(max_length=20)
    lby = models.ForeignKey('librarylis',related_name='bs',related_query_name='bt')
    def __str__(self):
        return  self.name

class Author(models.Model):
    name = models.CharField(max_length=20)
    book = models.ManyToManyField('Books')
```



```python

athor = models.Author.objects.get(pk=8)

ret = athor.book.create(name='飞翔人生',lby_id=8)
print(ret)

```

clear()

 删除所有多对多的关系

```python
athor.books.clear()
author_obj.books.set([])
```

**add()**

把指定的model对象添加到关联对象集中。

新增多对多的关系  

```python
athor = models.Author.objects.get(pk=8)
print(athor.book.add(models.Books.objects.filter(pk__in=[6,7])))
报错
"""
TypeError: int() argument must be a string, a bytes-like object or a number, not 'QuerySet'
"""
add（）接收的是一个位置参数。而models.Books.objects.filter()得到的是QuerySet的列表，所以需要打散。

正确的：
athor = models.Author.objects.get(pk=8)
方法一：
print(athor.book.add(*models.Books.objects.filter(pk__in=[6,7])))
方法二：
print(athor.book.add(6,7))
```

remove 删除多对多的关系   id，id              对象，对象

```python
# remove  删除多对多的关系   id，id   对象，对象
author_obj = models.Author.objects.get(pk=8)
# author_obj.books.remove(1,3)
# author_obj.book.remove(*models.Book.objects.filter(pk__in=[2,4]))
```

*# set（）  设置多对多的关系   [id，id]   [对象，对象]*

```python
*# author_obj.books.set([1,3])*
*# author_obj.books.set(models.Book.objects.filter(pk__in=[2,4]))
```

注意：

set和add的区别：

```python
# print(pub_obj.books.set(models.Book.objects.filter(pk__in=[3,4])))
# print(pub_obj.books.add(*models.Book.objects.filter(pk__in=[1])))
```

```python
# 外键的关系管理对象需要有remove和clear 外键字段必须可以为空
pub_obj = models.library.objects.get(pk=1)
print(pub_obj.books.all())
# print(pub_obj.books.remove(*models.Book.objects.filter(pk__in=[1])))
# print(pub_obj.books.clear())

# print(pub_obj.books.create(name="你喜欢的绿色"))

```

注意：

1. 对于所有类型的关联字段，add()、create()、remove()和clear(),set()都会马上更新数据库。换句话说，在关联的任何一端，都不需要再调用save()方法。

###### 8.聚合查询和分组

聚合：

`aggregate()`是`QuerySet` 的一个终止子句，意思是说，它返回一个包含一些键值对的字典。

键的名称是聚合值的标识符，值是计算出来的聚合值。键的名称是按照字段和聚合函数的名称自动生成出来的。

用到的内置函数：

```python
from django.db.models import Avg, Sum, Max, Min, Count
```

![1572854707554](django02.assets/1572854707554.png)

```python
from django.db.models import Avg, Sum, Max, Min, Count

print(models.Books.objects.all().aggregate(Avg('price')))
"""
{'price__avg': 126.75}
"""
```

如果你想要为聚合值指定一个名称，可以向聚合子句提供它。

```python
print(models.Books.objects.all().aggregate(book_avg_price = Avg('price')))

  """
  {'book_avg_price': 126.75}
  """
```

如果你希望生成不止一个聚合，你可以向`aggregate()`子句中添加另一个参数。所以，如果你也想知道所有图书价格的最大值和最小值，可以这样查询：

```python
from django.db.models import Avg, Sum, Max, Min, Count

print(models.Books.objects.all().aggregate(Avg('price'),Max('price'),Min('price')))
"""
{'price__avg': 126.75, 'price__max': Decimal('270.00'), 'price__min': Decimal('23.00')}
"""
```

分组：

*# 每一本书的作者个数*

```python
lis = models.Books.objects.all().annotate(count = Count('author'))
for i in lis:
    print(i,i.count)
    """
    金瓶梅 1
python 3
哇哈哈 3
linux 3
go语言 3
C语言深入剖析 3
飞翔人生 0
飞翔人生 1
    
    """
```

*# 统计出每个出版社买的最便宜的书的价格*

```python
#方法一
print(models.librarylis.objects.annotate(Min('bt__price')).values())
"""
<QuerySet [{'id': 10, 'name': '齐鲁出版社', 'addr': '苏州', 'phone': '123', 'bt__price__min': Decimal('100.00')}, {'id': 8, 'name': '苏教出版社', 'addr': '北京', 'phone': '123', 'bt__price__min': Decimal('23.00')}]>
"""
#方法二：
print(models.Books.objects.values('lby__id').annotate(Min('price')))
"""
<QuerySet [{'lby__id': 8, 'price__min': Decimal('23.00')}, {'lby__id': 10, 'price__min': Decimal('100.00')}]>

"""
```

*# 统计不止一个作者的图书*

```python
print(models.Books.objects.annotate(count = Count('author')).filter(count__gt=1))
for i in models.Books.objects.annotate(count = Count('author')).filter(count__gt=1):
    print(i.name,i.count)
print("*"*10)
for i in models.Books.objects.annotate(count = Count('author')):
    print(i.name,i.count)
"""
<QuerySet [<Books: python>, <Books: 哇哈哈>, <Books: linux>, <Books: go语言>, <Books: C语言深入剖析>]>
python 3
哇哈哈 3
linux 3
go语言 3
C语言深入剖析 3
**********
金瓶梅 1
python 3
哇哈哈 3
linux 3
go语言 3
C语言深入剖析 3
飞翔人生 0
飞翔人生 1
"""
```

*# 查询各个作者出的书的总价格*

```python
print(models.Author.objects.annotate(Sum('book__price')).values())

```

###### 9.F查询和Q查询

在上面所有的例子中，我们构造的过滤器都只是将字段值与某个常量做比较。如果我们要对两个字段的值做比较，那该怎么做呢？

Django 提供 F() 来做这样的比较。F() 的实例可以在查询中引用字段，来比较同一个 model 实例中两个不同字段的值。

示例1：

查询评论数大于收藏数的书籍

```python
from django.db.models import F
print(models.Books.objects.filter(sala__gt=F("kucun")))
```

Django 支持 F() 对象之间以及 F() 对象和常数之间的加减乘除和取模的操作。

```python
ret = models.Book.objects.all().update(publisher_id=3)

ret = models.Book.objects.filter(pk=1).update(sale=F('sale')*2+43)
```

```python
# & 与  and
# | 或  or
# ~ 非  not
# Q(pk__gt=5)
ret = models.Book.objects.filter(Q(~Q(pk__gt=5) | Q(pk__lt=3)) & Q(publisher_id__in=[1, 3]))

print(ret)
```

**引申：**

如果要修改char字段咋办？

如：把所有书名后面加上(第一版)

```python
>>> from django.db.models.functions import Concat
>>> from django.db.models import Value
>>> models.Book.objects.all().update(title=Concat(F("title"), Value("("), Value("第一版"), Value(")")))
```

Q查询

`filter()` 等方法中的关键字参数查询都是一起进行“AND” 的。 如果你需要执行更复杂的查询（例如`OR`语句），你可以使用`Q对象`。

示例1：

查询作者名是小仙女或小魔女的

```python
models.Book.objects.filter(Q(authors__name="小仙女")|Q(authors__name="小魔女"))
```

你可以组合`&` 和`|`  操作符以及使用括号进行分组来编写任意复杂的`Q` 对象。同时，`Q` 对象可以使用`~` 操作符取反，这允许组合正常的查询和取反(`NOT`) 查询。

示例：查询作者名字是小仙女并且不是2018年出版的书的书名。

```python
>>> models.Book.objects.filter(Q(author__name="小仙女") & ~Q(publish_date__year=2018)).values_list("title")
<QuerySet [('番茄物语',)]>
```

查询函数可以混合使用`Q 对象`和关键字参数。所有提供给查询函数的参数（关键字参数或`Q` 对象）都将"AND”在一起。但是，如果出现`Q` 对象，它必须位于所有关键字参数的前面。

例如：查询出版年份是2017或2018，书名中带物语的所有书。

```python
>>> models.Book.objects.filter(Q(publish_date__year=2018) | Q(publish_date__year=2017), title__icontains="物语")
<QuerySet [<Book: 番茄物语>, <Book: 香蕉物语>, <Book: 橘子物语>]>
```

###### 10.事务

```python
import os

if __name__ == '__main__':
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "BMS.settings")
    import django
    django.setup()

    import datetime
    from app01 import models

    try:
        from django.db import transaction
        with transaction.atomic():
            new_publisher = models.Publisher.objects.create(name="火星出版社")
            models.Book.objects.create(title="橘子物语", publish_date=datetime.date.today(), publisher_id=10)  # 指定一个不存在的出版社id
    except Exception as e:
        print(str(e))
```

### 6.Cookie

#### 1.什么是Cookie

##### 1.Cookie的由来

大家都知道HTTP协议是无状态的。

无状态的意思是每次请求都是独立的，它的执行情况和结果与前面的请求和之后的请求都无直接关系，它不会受前面的请求响应情况直接影响，也不会直接影响后面的请求响应情况。

一句有意思的话来描述就是人生只如初见，对服务器来说，每次的请求都是全新的。

状态可以理解为客户端和服务器在某次会话中产生的数据，那无状态的就以为这些数据不会被保留。会话中产生的数据又是我们需要保存的，也就是说要“保持状态”。因此Cookie就是在这样一个场景下诞生。

##### 2.什么是Cookie

Cookie具体指的是一段小信息，它是服务器发送出来存储在浏览器上的一组组键值对，下次访问服务器时浏览器会自动携带这些键值对，以便服务器提取有用信息。

##### 3.Cookie的原理

cookie的工作原理是：由服务器产生内容，浏览器收到请求后保存在本地；当浏览器再次访问时，浏览器会自动带上Cookie，这样服务器就能通过Cookie的内容来判断这个是“谁”了。

##### 4.查看Cookie

我们使用Chrome浏览器，打开开发者工具。

![1572939457343](django02.assets/1572939457343.png)

#### 2.Django中操作Cookie

##### 1.获取Cookie

```
request.COOKIES['key']
request.get_signed_cookie('key', default=RAISE_ERROR, salt='', max_age=None)
```

get_signed_cookie方法的参数：

- default: 默认值
- salt: 加密盐
- max_age: 后台控制过期时间

##### 2.设置Cookie

```
rep = HttpResponse(...)
rep ＝ render(request, ...)

rep.set_cookie(key,value,...)
rep.set_signed_cookie(key,value,salt='加密盐',...)
```

参数：

- key, 键
- value='', 值
- max_age=None, 超时时间
- expires=None, 超时时间(IE requires expires, so set it if hasn't been already.)
- path='/', Cookie生效的路径，/ 表示根路径，特殊的：根路径的cookie可以被任何url的页面访问
- domain=None, Cookie生效的域名
- secure=False, https传输
- httponly=False 只能http协议传输，无法被JavaScript获取（不是绝对，底层抓包可以获取到也可以被覆盖）

##### 3.删除Cookie

```
def logout(request):
    rep = redirect("/login/")
    rep.delete_cookie("user")  # 删除用户浏览器上之前设置的user的cookie值
    return rep
```

cookie登陆验证：

```python
def check_login(func):
    @wraps(func)
    def inner(request, *args, **kwargs):
        next_url = request.get_full_path()
        if request.get_signed_cookie("login", salt="SSS", default=None) == "yes":
            # 已经登录的用户...
            return func(request, *args, **kwargs)
        else:
            # 没有登录的用户，跳转刚到登录页面
            return redirect("/login/?next={}".format(next_url))
    return inner


def login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        passwd = request.POST.get("password")
        if username == "xxx" and passwd == "dashabi":
            next_url = request.GET.get("next")
            if next_url and next_url != "/logout/":
                response = redirect(next_url)
            else:
                response = redirect("/class_list/")
            response.set_signed_cookie("login", "yes", salt="SSS")
            return response
    return render(request, "login.html")
```

### 7.Session

#### 1.什么是session

##### 1.session的由来

Cookie虽然在一定程度上解决了“保持状态”的需求，但是由于Cookie本身最大支持4096字节，以及Cookie本身保存在客户端，可能被拦截或窃取，因此就需要有一种新的东西，它能支持更多的字节，并且他保存在服务器，有较高的安全性。这就是Session。

问题来了，基于HTTP协议的无状态特征，服务器根本就不知道访问者是“谁”。那么上述的Cookie就起到桥接的作用。

我们可以给每个客户端的Cookie分配一个唯一的id，这样用户在访问时，通过Cookie，服务器就知道来的人是“谁”。然后我们再根据不同的Cookie的id，在服务器上保存一段时间的私密资料，如“账号密码”等等。

总结而言：Cookie弥补了HTTP无状态的不足，让服务器知道来的人是“谁”；但是Cookie以文本的形式保存在本地，自身安全性较差；所以我们就通过Cookie识别不同的用户，对应的在Session里保存私密的信息以及超过4096字节的文本。

另外，上述所说的Cookie和Session其实是共通性的东西，不限于语言和框架。

Session:在计算机中，尤其是在网络应用中，称为“会话控制”。Session 对象存储特定用户会话所需的属性及配置信息。这样，当用户在应用程序的 Web 页之间跳转时，存储在 Session 对象中的变量将不会丢失，而是在整个用户会话中一直存在下去。当用户请求来自应用程序的 Web 页时，如果该用户还没有会话，则 Web 服务器将自动创建一个 Session 对象。当会话过期或被放弃后，服务器将终止该会话。Session 对象最常见的一个用法就是存储用户的首选项。

#### 2.django中的session相关方法

```python
# 获取、设置、删除Session中数据
request.session['k1']
request.session.get('k1',None)
request.session['k1'] = 123
request.session.setdefault('k1',123) # 存在则不设置
del request.session['k1']


# 所有 键、值、键值对
request.session.keys()
request.session.values()
request.session.items()
request.session.iterkeys()
request.session.itervalues()
request.session.iteritems()

# 会话session的key
request.session.session_key

# 将所有Session失效日期小于当前日期的数据删除
request.session.clear_expired()

# 检查会话session的key在数据库中是否存在
request.session.exists("session_key")

# 删除当前会话的所有Session数据
request.session.delete()
　　
# 删除当前的会话数据并删除会话的Cookie。
request.session.flush() 
    这用于确保前面的会话数据不可以再次被用户的浏览器访问
    例如，django.contrib.auth.logout() 函数中就会调用它。

# 设置会话Session和Cookie的超时时间
request.session.set_expiry(value)
    * 如果value是个整数，session会在些秒数后失效。
    * 如果value是个datatime或timedelta，session就会在这个时间后失效。
    * 如果value是0,用户关闭浏览器session就会失效。
    * 如果value是None,session会依赖全局session失效策略。
```

#### 3.session流程解析

session的底层是基于cookie技术来实现的，当用户打开浏览器，去访问服务器的时候，服务器会为每个用户的浏览器创建一个会话对象(session对象)，并且为每个session对象创建一个Jsessionid号。当session对象创建成功后，会以cookie的方式将这个Jsessionid号回写给浏览器，当用户再次进行访问服务器时，及带了具有Jsessionid号的cookie数据来一起访问服务器，服务器通过不同session的 Jsessionid号来找出与其相关联的session对象，通过不同的session对象来为不同的用户服务。

![1572961782277](django02.assets/1572961782277.png)

![1572961234554](django02.assets/1572961234554.png)

#### 4.session版登陆验证

```python
from functools import wraps


def check_login(func):
    @wraps(func)
    def inner(request, *args, **kwargs):
        next_url = request.get_full_path()
        if request.session.get("user"):
            return func(request, *args, **kwargs)
        else:
            return redirect("/login/?next={}".format(next_url))
    return inner


def login(request):
    if request.method == "POST":
        user = request.POST.get("user")
        pwd = request.POST.get("pwd")

        if user == "alex" and pwd == "alex1234":
            # 设置session
            request.session["user"] = user
            # 获取跳到登陆页面之前的URL
            next_url = request.GET.get("next")
            # 如果有，就跳转回登陆之前的URL
            if next_url:
                return redirect(next_url)
            # 否则默认跳转到index页面
            else:
                return redirect("/index/")
    return render(request, "login.html")


@check_login
def logout(request):
    # 删除所有当前请求相关的session
    request.session.delete()
    return redirect("/login/")


@check_login
def index(request):
    current_user = request.session.get("user", None)
    return render(request, "index.html", {"user": current_user})
```

#### 5.django中session配置

Django中默认支持Session，其内部提供了5种类型的Session供开发者使用。

```python
1. 数据库Session
SESSION_ENGINE = 'django.contrib.sessions.backends.db'   # 引擎（默认）

2. 缓存Session
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'  # 引擎
SESSION_CACHE_ALIAS = 'default'                            # 使用的缓存别名（默认内存缓存，也可以是memcache），此处别名依赖缓存的设置

3. 文件Session
SESSION_ENGINE = 'django.contrib.sessions.backends.file'    # 引擎
SESSION_FILE_PATH = None                                    # 缓存文件路径，如果为None，则使用tempfile模块获取一个临时地址tempfile.gettempdir() 

4. 缓存+数据库
SESSION_ENGINE = 'django.contrib.sessions.backends.cached_db'        # 引擎

5. 加密Cookie Session
SESSION_ENGINE = 'django.contrib.sessions.backends.signed_cookies'   # 引擎

其他公用设置项：
SESSION_COOKIE_NAME ＝ "sessionid"                       # Session的cookie保存在浏览器上时的key，即：sessionid＝随机字符串（默认）
SESSION_COOKIE_PATH ＝ "/"                               # Session的cookie保存的路径（默认）
SESSION_COOKIE_DOMAIN = None                             # Session的cookie保存的域名（默认）
SESSION_COOKIE_SECURE = False                            # 是否Https传输cookie（默认）
SESSION_COOKIE_HTTPONLY = True                           # 是否Session的cookie只支持http传输（默认）
SESSION_COOKIE_AGE = 1209600                             # Session的cookie失效日期（2周）（默认）
SESSION_EXPIRE_AT_BROWSER_CLOSE = False                  # 是否关闭浏览器使得Session过期（默认）
SESSION_SAVE_EVERY_REQUEST = False                       # 是否每次请求都保存Session，默认修改之后才保存（默认）
```

#### 6.源码流程

```python
Django session源码流程

首先执行的是SessionMiddleware的init方法
    import_module(settings.SESSION_ENGINE) 导入了一个 django.contrib.sessions.backends.db的包
    将db中SessionStore 赋值给self.SessionStore 
执行process_request    方法
    获取存放于cookie中的session_id,赋值为session_key
    实例化session仓库session_key作为参数，赋值给request.sessions
    
    执行SessionStore 的init方法
        执行父类SessionBase的init方法
            self._session_key = session_key
            将参数session_key 赋值给 self._session_key
            self.accessed = False  存取 session
            self.modified = False  修改session
        修改_session_key会执行下面
        _session_key = property(_get_session_key, _set_session_key)
        
        然后执行_set_session_key方法
            判断_session_key是否存在
                T:将其赋值给__session_key
                F:__session_key为None
    如果此时没有用户登录会执行__getitem__
        def __getitem__(self, key):
            return self._session[key]
            #self._session = _session_cache
    如果用户登录会给session赋值，执行__setitem__方法
        一键值对存放于self._session中
        self.modified = True 修改session
        
        因为self.session执行 _session = property(_get_session)
        执行_get_session方法
            self.accessed = True   #获取session
            
            如果self._session_cache 存在或者 no_load存在
                self._session_cache = {}
            否则
                self._session_cache = self.load()
                
            return self._session_cache
执行process_response方法
    accessed = request.session.accessed
    modified = request.session.modified
    判断session是否为空
        empty = request.session.is_empty()
            def is_empty(self):
                "Returns True when there is no session_key and the session is empty"
                try:
                    return not bool(self._session_key) and not self._session_cache    
                    return True
            如果此时self既有session_key又有session返回F，不为空（说明此时已经存在cookie与session）
            此时self如果没有属性_session_cache报错 为空
     判断sessionID是否存在于cookie中和 session是否存在（有cookie，没session）（绝对是注销操作）
        True，就删除并重新赋值cookie
     否则
        判断 accessed 存储是否为空（是否获取了session）
        判断session是否赋值和session不为空
            保存session并给cookie赋值
                保存session request.session.save()
                    获取sessionID
                    获取那个字典
                    生成model实例
                    写入到数据库
                给cookie赋值
                    session_id : fsufuhakjfhkuahfkdahkfhakfhakfhka
                    
                    
1.一直处于未登录
    1.获取到cookie的session_id 为空
    2.获取session的某个值，为空
    3.session没有被赋值，不执行
2.从未登录到登陆
    1.获取到cookie的session_id 为空
    2.给session赋值
    3.把session存放到数据库 sessionkey sessiondata 过期时间
    4.把sessionkey 存放到cookie sessionID 32位随机字符串
    
    认证原理：获取sessionkey 与数据库的sessionkey是否一致 一致就可取到 session data数据，然后取出判断此数据是否存在与数据库中
3.一直登陆
    1.获取到cookie的session_id 为32位随机字符串
    2.获取session某值，不为空
    3.session没有被赋值，不执行
4.注销
    1.获取到cookie的session_id 为32位随机字符串
    2.给session赋值
    3.把session存放到数据库 sessionkey sessiondata 过期时间 （sessiondata会被修改）
    4.把sessionkey 存放到cookie sessionID 32位随机字符串
    
    认证原理：获取cookie 的sessionkey 和 服务器的sessionkey字段 作比较 一致为 同一浏览器，但sessiondata 中的数据 向user表中查看
```

#### 7.源码

SessionMiddleware源码

```python
import time
from importlib import import_module

from django.conf import settings
from django.contrib.sessions.backends.base import UpdateError
from django.core.exceptions import SuspiciousOperation
from django.utils.cache import patch_vary_headers
from django.utils.deprecation import MiddlewareMixin
from django.utils.http import cookie_date


class SessionMiddleware(MiddlewareMixin):
    def __init__(self, get_response=None):
        self.get_response = get_response
        engine = import_module(settings.SESSION_ENGINE) #settings.SESSION_ENGINE = django.contrib.sessions.backends.db
        
        self.SessionStore = engine.SessionStore # class SessionStore(SessionBase): 实现数据库会话存储的类

    def process_request(self, request):
        session_key = request.COOKIES.get(settings.SESSION_COOKIE_NAME)  #SESSION_COOKIE_NAME = 'sessionid'
        request.session = self.SessionStore(session_key)  #实例化 SessionStore

    def process_response(self, request, response):
        """
        If request.session was modified, or if the configuration is to save the
        session every time, save the changes and set a session cookie or delete
        the session cookie if the session has been emptied.
        """
        try:
            accessed = request.session.accessed    #存取
            modified = request.session.modified    #修改
            empty = request.session.is_empty()
        except AttributeError:
            pass
        else:
            # First check if we need to delete this cookie.
            # The session should be deleted only if the session is entirely empty   
            if settings.SESSION_COOKIE_NAME in request.COOKIES and empty:   #cookie上的sessionkey sessiondata都为空 时执行这个
                response.delete_cookie(
                    settings.SESSION_COOKIE_NAME,
                    path=settings.SESSION_COOKIE_PATH,  #SESSION_COOKIE_PATH = '/'
                    domain=settings.SESSION_COOKIE_DOMAIN,#SESSION_COOKIE_DOMAIN = None
                )
            else:
                if accessed:
                    patch_vary_headers(response, ('Cookie',))
                if (modified or settings.SESSION_SAVE_EVERY_REQUEST) and not empty:
                    if request.session.get_expire_at_browser_close():
                        max_age = None
                        expires = None
                    else:
                        max_age = request.session.get_expiry_age()
                        expires_time = time.time() + max_age
                        expires = cookie_date(expires_time)
                    # Save the session data and refresh the client cookie.
                    # Skip session save for 500 responses, refs #3881.
                    if response.status_code != 500:
                        try:
                            request.session.save()
                        except UpdateError:
                            raise SuspiciousOperation(
                                "The request's session was deleted before the "
                                "request completed. The user may have logged "
                                "out in a concurrent request, for example."
                            )
                        response.set_cookie(
                            settings.SESSION_COOKIE_NAME,
                            request.session.session_key, max_age=max_age,
                            expires=expires, domain=settings.SESSION_COOKIE_DOMAIN,
                            path=settings.SESSION_COOKIE_PATH,
                            secure=settings.SESSION_COOKIE_SECURE or None,
                            httponly=settings.SESSION_COOKIE_HTTPONLY or None,
                        )
        return response
```

SessionStore:

```python
import logging

from django.contrib.sessions.backends.base import (
    CreateError, SessionBase, UpdateError,
)
from django.core.exceptions import SuspiciousOperation
from django.db import DatabaseError, IntegrityError, router, transaction
from django.utils import timezone
from django.utils.encoding import force_text
from django.utils.functional import cached_property


class SessionStore(SessionBase):
    """
    Implements database session store.
    """
    def __init__(self, session_key=None):
        super(SessionStore, self).__init__(session_key)

    @classmethod
    def get_model_class(cls):
        # Avoids a circular import and allows importing SessionStore when
        # django.contrib.sessions is not in INSTALLED_APPS.
        from django.contrib.sessions.models import Session
        return Session

    @cached_property
    def model(self):
        return self.get_model_class()

    def load(self):
        try:
            s = self.model.objects.get(
                session_key=self.session_key,
                expire_date__gt=timezone.now()
            )
            return self.decode(s.session_data)
        except (self.model.DoesNotExist, SuspiciousOperation) as e:
            if isinstance(e, SuspiciousOperation):
                logger = logging.getLogger('django.security.%s' % e.__class__.__name__)
                logger.warning(force_text(e))
            self._session_key = None
            return {}

    def exists(self, session_key):
        return self.model.objects.filter(session_key=session_key).exists()

    def create(self):
        while True:
            self._session_key = self._get_new_session_key()
            try:
                # Save immediately to ensure we have a unique entry in the
                # database.
                self.save(must_create=True)
            except CreateError:
                # Key wasn't unique. Try again.
                continue
            self.modified = True
            return

    def create_model_instance(self, data):
        """
        Return a new instance of the session model object, which represents the
        current session state. Intended to be used for saving the session data
        to the database.
        """
        return self.model(
            session_key=self._get_or_create_session_key(),  #获取session_key
            session_data=self.encode(data),   #那个字典
            expire_date=self.get_expiry_date(),
        )

    def save(self, must_create=False):
        """
        Saves the current session data to the database. If 'must_create' is
        True, a database error will be raised if the saving operation doesn't
        create a *new* entry (as opposed to possibly updating an existing
        entry).
        """
        if self.session_key is None:
            return self.create()
        data = self._get_session(no_load=must_create) #此时已经存在值了
        obj = self.create_model_instance(data)   #model实例
        using = router.db_for_write(self.model, instance=obj)    #from django.contrib.sessions.models import Session
        try:
            with transaction.atomic(using=using):
                #写入数据库
                obj.save(force_insert=must_create, force_update=not must_create, using=using)
        except IntegrityError:
            if must_create:
                raise CreateError
            raise
        except DatabaseError:
            if not must_create:
                raise UpdateError
            raise

    def delete(self, session_key=None):
        if session_key is None:
            if self.session_key is None:
                return
            session_key = self.session_key
        try:
            self.model.objects.get(session_key=session_key).delete()
        except self.model.DoesNotExist:
            pass

    @classmethod
    def clear_expired(cls):
        cls.get_model_class().objects.filter(expire_date__lt=timezone.now()).delete()
```

session:

```python
class SessionBase(object):
    """
    Base class for all Session classes.
    """
    TEST_COOKIE_NAME = 'testcookie'
    TEST_COOKIE_VALUE = 'worked'

    __not_given = object()

    def __init__(self, session_key=None):
        self._session_key = session_key
        self.accessed = False
        self.modified = False
        self.serializer = import_string(settings.SESSION_SERIALIZER)    #django.contrib.sessions.serializers.JSONSerializer
        #self.serializer = class JSONSerializer(object):  实现序列化方法的类
    def __contains__(self, key):
        return key in self._session

    def __getitem__(self, key):
        return self._session[key]

    def __setitem__(self, key, value):
        #self._session = _session_cache = {'name':'ldq'}
        self._session[key] = value  #因为字典是可变类型，所以当_session改变的时候_session_cache也随之改变
        self.modified = True

    def __delitem__(self, key):
        del self._session[key]
        self.modified = True

    def get(self, key, default=None):
        return self._session.get(key, default)

    def pop(self, key, default=__not_given):
        self.modified = self.modified or key in self._session
        args = () if default is self.__not_given else (default,)
        return self._session.pop(key, *args)

    def setdefault(self, key, value):
        if key in self._session:
            return self._session[key]
        else:
            self.modified = True
            self._session[key] = value
            return value

    def set_test_cookie(self):
        self[self.TEST_COOKIE_NAME] = self.TEST_COOKIE_VALUE

    def test_cookie_worked(self):
        return self.get(self.TEST_COOKIE_NAME) == self.TEST_COOKIE_VALUE

    def delete_test_cookie(self):
        del self[self.TEST_COOKIE_NAME]

    def _hash(self, value):
        key_salt = "django.contrib.sessions" + self.__class__.__name__
        return salted_hmac(key_salt, value).hexdigest()

    def encode(self, session_dict):
        "Returns the given session dictionary serialized and encoded as a string."
        serialized = self.serializer().dumps(session_dict)
        hash = self._hash(serialized)
        return base64.b64encode(hash.encode() + b":" + serialized).decode('ascii')

    def decode(self, session_data):
        encoded_data = base64.b64decode(force_bytes(session_data))
        try:
            # could produce ValueError if there is no ':'
            hash, serialized = encoded_data.split(b':', 1)
            expected_hash = self._hash(serialized)
            if not constant_time_compare(hash.decode(), expected_hash):
                raise SuspiciousSession("Session data corrupted")
            else:
                return self.serializer().loads(serialized)
        except Exception as e:
            # ValueError, SuspiciousOperation, unpickling exceptions. If any of
            # these happen, just return an empty dictionary (an empty session).
            if isinstance(e, SuspiciousOperation):
                logger = logging.getLogger('django.security.%s' % e.__class__.__name__)
                logger.warning(force_text(e))
            return {}

    def update(self, dict_):
        self._session.update(dict_)
        self.modified = True

    def has_key(self, key):
        return key in self._session

    def keys(self):
        return self._session.keys()

    def values(self):
        return self._session.values()

    def items(self):
        return self._session.items()

    def iterkeys(self):
        return self._session.iterkeys()

    def itervalues(self):
        return self._session.itervalues()

    def iteritems(self):
        return self._session.iteritems()

    def clear(self):
        # To avoid unnecessary persistent storage accesses, we set up the
        # internals directly (loading data wastes time, since we are going to
        # set it to an empty dict anyway).
        self._session_cache = {}
        self.accessed = True
        self.modified = True

    def is_empty(self):
        "Returns True when there is no session_key and the session is empty"
        try:
            return not bool(self._session_key) and not self._session_cache    #如果此时self既有session_key又有session返回F：不为空（说明此时已经存在cookie与session）
        except AttributeError:
            return True

    def _get_new_session_key(self):
        "Returns session key that isn't being used."
        while True:
            session_key = get_random_string(32, VALID_KEY_CHARS)  #32位的随机字符串
            if not self.exists(session_key):
                break
        return session_key 

    def _get_or_create_session_key(self):
        if self._session_key is None:
            self._session_key = self._get_new_session_key()
        return self._session_key

    def _validate_session_key(self, key):
        """
        Key must be truthy and at least 8 characters long. 8 characters is an
        arbitrary lower bound for some minimal key security.
        """
        return key and len(key) >= 8

    def _get_session_key(self):
        return self.__session_key

    def _set_session_key(self, value):    #对象实例化时执行这个方法
        """
        Validate session key on assignment. Invalid values will set to None.
        """
        if self._validate_session_key(value):
            self.__session_key = value
        else:
            self.__session_key = None

    session_key = property(_get_session_key)  #None
    _session_key = property(_get_session_key, _set_session_key)  #self._session_key = self._get_new_session_key() #32位的随机字符串

    def _get_session(self, no_load=False):
        """
        Lazily loads session from storage (unless "no_load" is True, when only
        an empty dict is stored) and stores it in the current instance.
        """
        self.accessed = True   #正在获取session
        try:
            return self._session_cache
        except AttributeError:
            if self.session_key is None or no_load:
                self._session_cache = {}
            else:
                self._session_cache = self.load()
        return self._session_cache

    _session = property(_get_session)

    def get_expiry_age(self, **kwargs):
        """Get the number of seconds until the session expires.

        Optionally, this function accepts `modification` and `expiry` keyword
        arguments specifying the modification and expiry of the session.
        """
        try:
            modification = kwargs['modification']
        except KeyError:
            modification = timezone.now()
        # Make the difference between "expiry=None passed in kwargs" and
        # "expiry not passed in kwargs", in order to guarantee not to trigger
        # self.load() when expiry is provided.
        try:
            expiry = kwargs['expiry']
        except KeyError:
            expiry = self.get('_session_expiry')

        if not expiry:   # Checks both None and 0 cases
            return settings.SESSION_COOKIE_AGE
        if not isinstance(expiry, datetime):
            return expiry
        delta = expiry - modification
        return delta.days * 86400 + delta.seconds

    def get_expiry_date(self, **kwargs):
        """Get session the expiry date (as a datetime object).

        Optionally, this function accepts `modification` and `expiry` keyword
        arguments specifying the modification and expiry of the session.
        """
        try:
            modification = kwargs['modification']
        except KeyError:
            modification = timezone.now()
        # Same comment as in get_expiry_age
        try:
            expiry = kwargs['expiry']
        except KeyError:
            expiry = self.get('_session_expiry')

        if isinstance(expiry, datetime):
            return expiry
        if not expiry:   # Checks both None and 0 cases
            expiry = settings.SESSION_COOKIE_AGE    #SESSION_COOKIE_AGE = 60 * 60 * 24 * 7 * 2

        return modification + timedelta(seconds=expiry)

    def set_expiry(self, value):
        """
        Sets a custom expiration for the session. ``value`` can be an integer,
        a Python ``datetime`` or ``timedelta`` object or ``None``.

        If ``value`` is an integer, the session will expire after that many
        seconds of inactivity. If set to ``0`` then the session will expire on
        browser close.

        If ``value`` is a ``datetime`` or ``timedelta`` object, the session
        will expire at that specific future time.

        If ``value`` is ``None``, the session uses the global session expiry
        policy.
        """
        if value is None:
            # Remove any custom expiration for this session.
            try:
                del self['_session_expiry']
            except KeyError:
                pass
            return
        if isinstance(value, timedelta):
            value = timezone.now() + value
        self['_session_expiry'] = value

    def get_expire_at_browser_close(self):
        """
        Returns ``True`` if the session is set to expire when the browser
        closes, and ``False`` if there's an expiry date. Use
        ``get_expiry_date()`` or ``get_expiry_age()`` to find the actual expiry
        date/age, if there is one.
        """
        if self.get('_session_expiry') is None:
            return settings.SESSION_EXPIRE_AT_BROWSER_CLOSE
        return self.get('_session_expiry') == 0

    def flush(self):
        """
        Removes the current session data from the database and regenerates the
        key.
        """
        self.clear()
        self.delete()
        self._session_key = None

    def cycle_key(self):
        """
        Creates a new session key, while retaining the current session data.
        """
        data = self._session
        key = self.session_key
        self.create()
        self._session_cache = data
        if key:
            self.delete(key)

    # Methods that child classes must implement.

    def exists(self, session_key):
        """
        Returns True if the given session_key already exists.
        """
        raise NotImplementedError('subclasses of SessionBase must provide an exists() method')

    def create(self):
        """
        Creates a new session instance. Guaranteed to create a new object with
        a unique key and will have saved the result once (with empty data)
        before the method returns.
        """
        raise NotImplementedError('subclasses of SessionBase must provide a create() method')

    def save(self, must_create=False):
        """
        Saves the session data. If 'must_create' is True, a new session object
        is created (otherwise a CreateError exception is raised). Otherwise,
        save() only updates an existing object and does not create one
        (an UpdateError is raised).
        """
        raise NotImplementedError('subclasses of SessionBase must provide a save() method')

    def delete(self, session_key=None):
        """
        Deletes the session data under this key. If the key is None, the
        current session key value is used.
        """
        raise NotImplementedError('subclasses of SessionBase must provide a delete() method')

    def load(self):
        """
        Loads the session data and returns a dictionary.
        """
        raise NotImplementedError('subclasses of SessionBase must provide a load() method')

    @classmethod
    def clear_expired(cls):
        """
        Remove expired sessions from the session store.

        If this operation isn't possible on a given backend, it should raise
        NotImplementedError. If it isn't necessary, because the backend has
        a built-in expiration mechanism, it should be a no-op.
        """
        raise NotImplementedError('This backend does not support clear_expired().')
```

### 8.middleware 中间件

#### 1.什么是中间件

中间件介绍：

官方的说法：中间件是一个用来处理Django的请求和响应的框架级别的钩子。它是一个轻量、低级别的插件系统，用于在全局范围内改变Django的输入和输出。每个中间件组件都负责做一些特定的功能。

但是由于其影响的是全局，所以需要谨慎使用，使用不当会影响性能。

说的直白一点中间件是帮助我们在视图函数执行之前和执行之后都可以做一些额外的操作，它本质上就是一个自定义类，类中定义了几个方法，Django框架会在处理请求的特定的时间去执行这些方法。

我们一直都在使用中间件，只是没有注意到而已，打开Django项目的Settings.py文件，看到下图的MIDDLEWARE配置项。

```python
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

```

MIDDLEWARE配置项是一个列表，列表中是一个个字符串，这些字符串其实是一个个类，也就是一个个中间件。

我们之前已经接触过一个csrf相关的中间件了？我们一开始让大家把他注释掉，再提交post请求的时候，就不会被forbidden了，后来学会使用csrf_token之后就不再注释这个中间件了。

那接下来就学习中间件中的方法以及这些方法什么时候被执行。

#### 2.自定义中间件

中间件可以定义五个方法，分别是：（主要的是process_request和process_response）

- process_request(self,request)
- process_view(self, request, view_func, view_args, view_kwargs)
- process_template_response(self,request,response)
- process_exception(self, request, exception)
- process_response(self, request, response)

以上方法的返回值可以是None或一个HttpResponse对象，如果是None，则继续按照django定义的规则向后继续执行，如果是HttpResponse对象，则直接将该对象返回给用户。

示例：

```python
from django.utils.deprecation import MiddlewareMixin


class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response
```

##### 1.process_request

process_request有一个参数，就是request，这个request和视图函数中的request是一样的。

它的返回值可以是None也可以是HttpResponse对象。返回值是None的话，按正常流程继续走，交给下一个中间件处理，如果是HttpResponse对象，Django将不执行视图函数，而将响应对象返回给浏览器。

我们来看看多个中间件时，Django是如何执行其中的process_request方法的。

```python
from django.utils.deprecation import MiddlewareMixin


class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")


class MD2(MiddlewareMixin):
    def process_request(self, request):
        print("MD2里面的 process_request")
```

在settings.py的MIDDLEWARE配置项中注册上述两个自定义中间件：

```python
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'middlewares.MD1',  # 自定义中间件MD1
    'middlewares.MD2'  # 自定义中间件MD2
]
```



此时，我们访问一个视图，会发现终端中打印如下内容：

```
MD1里面的 process_request
MD2里面的 process_requestapp01 中的 index视图
```

把MD1和MD2的位置调换一下，再访问一个视图，会发现终端中打印的内容如下：

```
MD2里面的 process_request
MD1里面的 process_requestapp01 中的 index视图
```

看结果我们知道：视图函数还是最后执行的，MD2比MD1先执行自己的process_request方法。

在打印一下两个自定义中间件中process_request方法中的request参数，会发现它们是同一个对象。

由此总结一下：

1. 中间件的process_request方法是在执行视图函数之前执行的。
2. 当配置多个中间件时，会按照MIDDLEWARE中的注册顺序，也就是列表的索引值，从前到后依次执行的。
3. 不同中间件之间传递的request都是同一个对象

#####   2.process_reponse

它有两个参数，一个是request，一个是response，request就是上述例子中一样的对象，response是视图函数返回的HttpResponse对象。该方法的返回值也必须是HttpResponse对象。

给上述的M1和M2加上process_response方法：

```python
from django.utils.deprecation import MiddlewareMixin


class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response


class MD2(MiddlewareMixin):
    def process_request(self, request):
        print("MD2里面的 process_request")

    def process_response(self, request, response):
        print("MD2里面的 process_response")
        return response
```

访问一个视图，看一下终端的输出：

```
MD2里面的 process_request
MD1里面的 process_request
app01 中的 index视图
MD1里面的 process_response
MD2里面的 process_response
```

看结果可知：

process_response方法是在视图函数之后执行的，并且顺序是MD1比MD2先执行。(此时settings.py中 MD2比MD1先注册)

多个中间件中的process_response方法是按照MIDDLEWARE中的注册顺序**倒序**执行的，也就是说第一个中间件的process_request方法首先执行，而它的process_response方法最后执行，最后一个中间件的process_request方法最后一个执行，它的process_response方法是最先执行。



##### 3.process_view

process_view(self, request, view_func, view_args, view_kwargs)

该方法有四个参数

request是HttpRequest对象。

view_func是Django即将使用的视图函数。 （它是实际的函数对象，而不是函数的名称作为字符串。）

view_args是将传递给视图的位置参数的列表.

view_kwargs是将传递给视图的关键字参数的字典。 view_args和view_kwargs都不包含第一个视图参数（request）。

Django会在调用视图函数之前调用process_view方法。

它应该返回None或一个HttpResponse对象。 如果返回None，Django将继续处理这个请求，执行任何其他中间件的process_view方法，然后在执行相应的视图。 如果它返回一个HttpResponse对象，Django不会调用适当的视图函数。 它将执行中间件的process_response方法并将应用到该HttpResponse并返回结果。

 给MD1和MD2添加process_view方法:

```python
from django.utils.deprecation import MiddlewareMixin


class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD1 中的process_view")
        print(view_func, view_func.__name__)


class MD2(MiddlewareMixin):
    def process_request(self, request):
        print("MD2里面的 process_request")

    def process_response(self, request, response):
        print("MD2里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD2 中的process_view")
        print(view_func, view_func.__name__)
```

访问index视图函数，看一下输出结果：

```python
MD2里面的 process_request
MD1里面的 process_request
--------------------------------------------------------------------------------
MD2 中的process_view
<function index at 0x000001DE68317488> index
--------------------------------------------------------------------------------
MD1 中的process_view
<function index at 0x000001DE68317488> index
app01 中的 index视图
MD1里面的 process_response
MD2里面的 process_response
```

process_view方法是在process_request之后，视图函数之前执行的，执行顺序按照MIDDLEWARE中的注册顺序**从前到后顺序**执行的

##### 4.process_exception

process_exception(self, request, exception)

该方法两个参数:

一个HttpRequest对象

一个exception是视图函数异常产生的Exception对象。

这个方法只有在视图函数中出现异常了才执行，它返回的值可以是一个None也可以是一个HttpResponse对象。如果是HttpResponse对象，Django将调用模板和中间件中的process_response方法，并返回给浏览器，否则将默认处理异常。如果返回一个None，则交给下一个中间件的process_exception方法来处理异常。它的执行顺序也是按照中间件注册顺序的倒序执行。

 给MD1和MD2添加上这个方法

```python
from django.utils.deprecation import MiddlewareMixin


class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD1 中的process_view")
        print(view_func, view_func.__name__)

    def process_exception(self, request, exception):
        print(exception)
        print("MD1 中的process_exception")


class MD2(MiddlewareMixin):
    def process_request(self, request):
        print("MD2里面的 process_request")

    def process_response(self, request, response):
        print("MD2里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD2 中的process_view")
        print(view_func, view_func.__name__)

    def process_exception(self, request, exception):
        print(exception)
        print("MD2 中的process_exception")
```

如果视图函数中无异常，process_exception方法不执行。

想办法，在视图函数中抛出一个异常：

```python
def index(request):
    print("app01 中的 index视图")
    raise ValueError("呵呵")
    return HttpResponse("O98K")
```

在MD1的process_exception中返回一个响应对象：

```python
class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD1 中的process_view")
        print(view_func, view_func.__name__)

    def process_exception(self, request, exception):
        print(exception)
        print("MD1 中的process_exception")
        return HttpResponse(str(exception))  # 返回一个响应对象
```

看输出结果：

```python
MD2里面的 process_request
MD1里面的 process_request
--------------------------------------------------------------------------------
MD2 中的process_view
<function index at 0x0000022C09727488> index
--------------------------------------------------------------------------------
MD1 中的process_view
<function index at 0x0000022C09727488> index
app01 中的 index视图
呵呵
MD1 中的process_exception
MD1里面的 process_response
MD2里面的 process_response
```

注意，这里并没有执行MD2的process_exception方法，因为MD1中的process_exception方法直接返回了一个响应对象

##### 5.process_template_response

process_template_response(self, request, response)

它的参数，一个HttpRequest对象，response是TemplateResponse对象（由视图函数或者中间件产生）。

process_template_response是在视图函数执行完成后立即执行，但是它有一个前提条件，那就是视图函数返回的对象有一个render()方法（或者表明该对象是一个TemplateResponse对象或等价方法）。

```python
class MD1(MiddlewareMixin):

    def process_request(self, request):
        print("MD1里面的 process_request")

    def process_response(self, request, response):
        print("MD1里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD1 中的process_view")
        print(view_func, view_func.__name__)

    def process_exception(self, request, exception):
        print(exception)
        print("MD1 中的process_exception")
        return HttpResponse(str(exception))

    def process_template_response(self, request, response):
        print("MD1 中的process_template_response")
        return response


class MD2(MiddlewareMixin):
    def process_request(self, request):
        print("MD2里面的 process_request")

    def process_response(self, request, response):
        print("MD2里面的 process_response")
        return response

    def process_view(self, request, view_func, view_args, view_kwargs):
        print("-" * 80)
        print("MD2 中的process_view")
        print(view_func, view_func.__name__)

    def process_exception(self, request, exception):
        print(exception)
        print("MD2 中的process_exception")

    def process_template_response(self, request, response):
        print("MD2 中的process_template_response")
        return response
```



views.py

```python
def index(request):
    print("app01 中的 index视图")

    def render():
        print("in index/render")
        return HttpResponse("O98K")
    rep = HttpResponse("OK")
    rep.render = render
    return rep
```

访问index视图，终端输出的结果

```python
MD2里面的 process_request
MD1里面的 process_request
--------------------------------------------------------------------------------
MD2 中的process_view
<function index at 0x000001C111B97488> index
--------------------------------------------------------------------------------
MD1 中的process_view
<function index at 0x000001C111B97488> index
app01 中的 index视图
MD1 中的process_template_response
MD2 中的process_template_response
in index/render
MD1里面的 process_response
MD2里面的 process_response
```

从结果看出：

视图函数执行完之后，立即执行了中间件的process_template_response方法，顺序是倒序，先执行MD1的，在执行MD2的，接着执行了视图函数返回的HttpResponse对象的render方法，返回了一个新的HttpResponse对象，接着执行中间件的process_response方法。

#### 3.中间件的执行流程

请求到达中间件之后，先按照正序执行每个注册中间件的process_reques方法，process_request方法返回的值是None，就依次执行，如果返回的值是HttpResponse对象，不再执行后面的process_request方法，而是执行当前对应中间件的process_response方法，将HttpResponse对象返回给浏览器。也就是说：如果MIDDLEWARE中注册了6个中间件，执行过程中，第3个中间件返回了一个HttpResponse对象，那么第4,5,6中间件的process_request和process_response方法都不执行，顺序执行3,2,1中间件的process_response方法。

![1573026518737](django02.assets/1573026518737.png)

process_request方法都执行完后，匹配路由，找到要执行的视图函数，先不执行视图函数，先执行中间件中的process_view方法，process_view方法返回None，继续按顺序执行，所有process_view方法执行完后执行视图函数。假如中间件3 的process_view方法返回了HttpResponse对象，则4,5,6的process_view以及视图函数都不执行，直接从最后一个中间件，也就是中间件6的process_response方法开始倒序执行。

![1573026534368](django02.assets/1573026534368.png)

process_template_response和process_exception两个方法的触发是有条件的，执行顺序也是倒序。总结所有的执行流程如下：

![1573026552752](django02.assets/1573026552752.png)

![1573026567406](django02.assets/1573026567406.png)



#### 4.中间件版登录验证 

中间件版的登录验证需要依靠session，所以数据库中要有django_session表。

urls.py

```python
from django.conf.urls import url
from django.contrib import admin
from app01 import views

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^login/$', views.login, name='login'),
    url(r'^index/$', views.index, name='index'),
    url(r'^home/$', views.home, name='home'),
]
```

views.py

```python
from django.shortcuts import render, HttpResponse, redirect


def index(request):
    return HttpResponse('this is index')


def home(request):
    return HttpResponse('this is home')


def login(request):
    if request.method == "POST":
        user = request.POST.get("user")
        pwd = request.POST.get("pwd")

        if user == "alex" and pwd == "alex3714":
            # 设置session
            request.session["user"] = user
            # 获取跳到登陆页面之前的URL
            next_url = request.GET.get("next")
            # 如果有，就跳转回登陆之前的URL
            if next_url:
                return redirect(next_url)
            # 否则默认跳转到index页面
            else:
                return redirect("/index/")
    return render(request, "login.html")
```

login.html

```python
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>登录页面</title>
</head>
<body>
<form action="{% url 'login' %}" method="post">
    {% csrf_token %}
    <p>
        <label for="user">用户名：</label>
        <input type="text" name="user" id="user">
    </p>
    <p>
        <label for="pwd">密 码：</label>
        <input type="text" name="pwd" id="pwd">
    </p>
    <input type="submit" value="登录">
</form>
</body>
</html>
```

middlewares.py

```python
from django.utils.deprecation import MiddlewareMixin


class AuthMD(MiddlewareMixin):
    white_list = ['/login/', ]  # 白名单
    black_list = ['/black/', ]  # 黑名单

    def process_request(self, request):
        from django.shortcuts import redirect, HttpResponse

        next_url = request.path_info
        print(request.path_info, request.get_full_path())
        # 黑名单的网址限制访问
        if next_url in self.black_list:
            return HttpResponse('This is an illegal URL')
        # 白名单的网址或者登陆用户不做限制
        elif next_url in self.white_list or request.session.get("user"):
            return
        else:
            return redirect("/login/?next={}".format(next_url))
```

在settings.py中注册

```python
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.ming
    'middlewares.AuthMD'
]
```

AuthMD中间件注册后，所有的请求都要走AuthMD的process_request方法。

如果URL在黑名单中，则返回This is an illegal URL的字符串；

访问的URL在白名单内或者session中有user用户名，则不做阻拦走正常流程；

正常的URL但是需要登录后访问，让浏览器跳转到登录页面。

注：AuthMD中间件中需要session，所以AuthMD注册的位置要在session中间的下方。 

5.django请求流程图

![1168194-20180719084357413-1778333372](C:/Users/32639/Desktop/1168194-20180719084357413-1778333372.png)

#### 总结：

##### 中间件

中间件  ：中间件就是一个类，在全局范围内处理django的请求和响应。

类    5个方法     4个特点

###### process_request(self,request)

执行时间：

​		在视图函数之前

执行顺序： 

​		按照注册的顺序 顺序执行

参数 ：  

​			request：  请求的对象，和视图函数是同一个

返回值：

​		None :   正常流程 

​		HttpResponse:之后中间件的process_request、路由、process_view、视图都不执行，执行执行当前中间件对应process_response方法，接着倒序执行之前的中间件中的process_response方法。



###### process_response(self, request, response)

执行时间：

​		在视图函数之后

执行顺序： 

​		按照注册的顺序 倒序执行

参数 ：  

​			request：  请求的对象，和视图函数是同一个

​			response： 响应对象

返回值：

​		HttpResponse: 必须返回



###### process_view(self, request, view_func, view_args, view_kwargs)

执行时间：

​		在路由匹配之后，在视图函数之前

执行顺序： 

​		按照注册的顺序 顺序执行

参数 ：  

​			request：  请求的对象，和视图函数是同一个

​			view_func：视图函数

​			view_args:   给视图传递的位置参数

​			view_kwargs：  给视图传递的关键字参数

返回值：

​			None：  正常流程

​		    HttpResponse: 之后中间件的process_view、视图都不执行，直接执行最后一个中间件process_response，倒序执行之前中间件的process_response方法

###### process_exception(self, request, exception)

执行时间：

​		在视图函数出错之后执行

执行顺序： 

​		按照注册的顺序 倒序执行

参数 ：  

​			request：  请求的对象，和视图函数是同一个

​			exception：报错的对象

返回值：

​			None：  自己没有处理，交给下一个中间件处理，所有的中间件都没有处理，django处理错误。

​		    HttpResponse: 之后中间件的process_exception，直接执行最后一个中间件process_response，倒序执行之前中间件的process_response方法

###### process_template_response(self,request,response)

执行时间：

​		当视图函数返回一个TemplateResponse对象

执行顺序： 

​		按照注册的顺序 倒序执行

参数 ：  

​			request：  请求的对象，和视图函数是同一个

​			response：响应的对象

返回值：

​		    HttpResponse: 必须返回



### 9.Ajax













总结：

ajax

js技术，发请求。

特点：

1. 异步 
2. 局部刷新
3. 数据量小 

发请求的方式:

1. 地址栏输入地址  get
2. a标签    get
3. form  get /post
    1. action  提交的地址   method='post'   上传的文件的 enctype="multipart/form-data"
    2. 有button或者 input类型submit 
    3. input 标签有name属性 有的需要有value
4. ajax

简单使用：

使用jq发送ajax请求

```js
$.ajax({
    url:'' ,  //  请求发送的地址
    type：'post',   //  请求方式
    data: {} ,  //  数据
    success:function (res){}      //  响应成功之后执行的回调函数  res返回的响应体 
    
})
```

上传文件

```js
var form_data  =  new FormData()
form_data.append('k1','v1')
form_data.append('f1',$('#f1')[0].files[0])

$.ajax({
    url:'' ,  //  请求发送的地址
    type：'post',   //  请求方式
    data:form_data ,  //  数据
    processData:false,   //  不需要处理数据的编码 multipart/form-data
    contentType:false,   //  不需要处理contentType的请求头
    success:function (res){}      //  响应成功之后执行的回调函数  res返回的响应体 
    
})

```

ajax通过django的csrf的校验

前提：必须要有csrftoken的cookie

方式一：

给data添加csrfmiddlewaretoken键值对

方式二：

给headers 添加  x-csrftoken的键值对 

方式三：

导入文件

csrf相关装饰器

```
from django.views.decorators.csrf import ensure_csrf_cookie,csrf_exempt,csrf_protect

# ensure_csrf_cookie  确保有cookie
# csrf_exempt   不需要进行csrf的校验
# csrf_protect  需要进行csrf的校验

注意：  csrf_exempt CBV的时候只能加载dispatch方法上
```

## 



### 10.form组件

#### 1、form介绍

我们之前在HTML页面中利用form表单向后端提交数据时，都会写一些获取用户输入的标签并且用form标签把它们包起来。

与此同时我们在好多场景下都需要对用户的输入做校验，比如校验用户是否输入，输入的长度和格式等正不正确。如果用户输入的内容有错误就需要在页面上相应的位置显示对应的错误信息.。

Django form组件就实现了上面所述的功能。

总结一下，其实form组件的主要功能如下:

- 生成页面可用的HTML标签

- 对用户提交的数据进行校验

- 保留上次输入内容

- 错误提示

    

#### 2、普通方式手写注册功能

Views.py

```python
def register(request):
    error_msg = ""
    if request.method == "POST":
        username = request.POST.get("name")
        pwd = request.POST.get("pwd")
        # 对注册信息做校验
        if len(username) < 6:
            # 用户长度小于6位
            error_msg = "用户名长度不能小于6位"
        else:
            # 将用户名和密码存到数据库
            return HttpResponse("注册成功")
    return render(request, "register.html", {"error_msg": error_msg})
```

login.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>注册页面</title>
</head>
<body>
<form action="/reg/" method="post">
    {% csrf_token %}
    <p>
        用户名:
        <input type="text" name="name">
    </p>
    <p>
        密码：
        <input type="password" name="pwd">
    </p>
    <p>
        <input type="submit" value="注册">
        <p style="color: red">{{ error_msg }}</p>
    </p>
</form>
</body>
</html>
```

#### 3、使用form组件实现注册功能

View.py

```python
from django.shortcuts import render
from django import forms
from django.http import  HttpResponse

# Create your views here.
class Regirst(forms.Form):
    user = forms.CharField(label='用户名',min_length=6,disabled=False,required=True)
    pwd = forms.CharField(label='密码',widget=forms.PasswordInput,min_length=6)
    repwd = forms.CharField(label='确认密码',widget=forms.PasswordInput,min_length=6)


def regisister(request):
    if request.method =='POST':

        reg_obj = Regirst(request.POST)
        if reg_obj.is_valid():
            print(reg_obj.fields.items())
            print('成功')
            return  HttpResponse('注册成功')
    reg_obj = Regirst()
    return  render(request,'register.html',{'reg_obj':reg_obj})
```

register.html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="" method="post">
    {% csrf_token %}
{#    {{ reg_obj.as_p }}#}
    <p>
    <label>{{ reg_obj.user.label }}</label>
        {{reg_obj.user  }}
    </p>
     <p>
    <label>{{ reg_obj.pwd.label }}</label>
        {{reg_obj.pwd  }}
    </p>
     <p>
    <label>{{ reg_obj.repwd.label }}</label>
        {{reg_obj.repwd  }}
    </p>

    <button type="submit">确认</button>

</form>

</body>
</html>
```

看网页效果发现 也验证了form的功能：
• 前端页面是form类的对象生成的                                      -->生成HTML标签功能
• 当用户名和密码输入为空或输错之后 页面都会提示        -->用户提交校验功能
• 当用户输错之后 再次输入 上次的内容还保留在input框   -->保留上次输入内容



#### 4、Form

##### 1、常用字段与插件

创建Form类时，主要涉及到 【字段】 和 【插件】，字段用于对用户请求数据的验证，插件用于自动生成HTML;

###### initial

初始值，input框里面的初始值。

```python
class LoginForm(forms.Form):
    username = forms.CharField(
        min_length=8,
        label="用户名",
        initial="张三"  # 设置默认值
    )
    pwd = forms.CharField(min_length=6, label="密码")
```

###### error_messages

重写错误信息

```python
class LoginForm(forms.Form):
    username = forms.CharField(
        min_length=8,
        label="用户名",
        initial="张三",
        error_messages={
            "required": "不能为空",
            "invalid": "格式错误",
            "min_length": "用户名最短8位"
        }
    )
    pwd = forms.CharField(min_length=6, label="密码")
```



###### password

```python
class LoginForm(forms.Form):
    ...
    pwd = forms.CharField(
        min_length=6,
        label="密码",
        widget=forms.widgets.PasswordInput(attrs={'class': 'c1'}, render_value=True)
    )
```

###### radioSelect

单radio值为字符串

```python
class LoginForm(forms.Form):
    username = forms.CharField(
        min_length=8,
        label="用户名",
        initial="张三",
        error_messages={
            "required": "不能为空",
            "invalid": "格式错误",
            "min_length": "用户名最短8位"
        }
    )
    pwd = forms.CharField(min_length=6, label="密码")
    gender = forms.fields.ChoiceField(
        choices=((1, "男"), (2, "女"), (3, "保密")),
        label="性别",
        initial=3,
        widget=forms.widgets.RadioSelect()
    )
```



###### 单选Select

```python
class LoginForm(forms.Form):
    ...
    hobby = forms.fields.ChoiceField(
        choices=((1, "篮球"), (2, "足球"), (3, "双色球"), ),
        label="爱好",
        initial=3,
        widget=forms.widgets.Select()
    )
```

###### 多选Select



```
class LoginForm(forms.Form):
    ...
    hobby = forms.fields.MultipleChoiceField(
        choices=((1, "篮球"), (2, "足球"), (3, "双色球"), ),
        label="爱好",
        initial=[1, 3],
        widget=forms.widgets.SelectMultiple()
    )
```



###### 单选checkbox



```
class LoginForm(forms.Form):
    ...
    keep = forms.fields.ChoiceField(
        label="是否记住密码",
        initial="checked",
        widget=forms.widgets.CheckboxInput()
    )
```





###### 多选checkbox



```
class LoginForm(forms.Form):
    ...
    hobby = forms.fields.MultipleChoiceField(
        choices=((1, "篮球"), (2, "足球"), (3, "双色球"),),
        label="爱好",
        initial=[1, 3],
        widget=forms.widgets.CheckboxSelectMultiple()
    )
```



关于choice的注意事项：

在使用选择标签时，需要注意choices的选项可以从数据库中获取，但是由于是静态字段 ***获取的值无法实时更新***，那么需要自定义构造方法从而达到此目的。

方式一：



```
from django.forms import Form
from django.forms import widgets
from django.forms import fields

 
class MyForm(Form):
 
    user = fields.ChoiceField(
        # choices=((1, '上海'), (2, '北京'),),
        initial=2,
        widget=widgets.Select
    )
 
    def __init__(self, *args, **kwargs):
        super(MyForm,self).__init__(*args, **kwargs)
        # self.fields['user'].choices = ((1, '上海'), (2, '北京'),)
        # 或
        self.fields['user'].choices = models.Classes.objects.all().values_list('id','caption')
```

方式二：



```
from django import forms
from django.forms import fields
from django.forms import models as form_model

 
class FInfo(forms.Form):
    authors = form_model.ModelMultipleChoiceField(queryset=models.NNewType.objects.all())  # 多选
    # authors = form_model.ModelChoiceField(queryset=models.NNewType.objects.all())  # 单选
```

##### 2、Django Form所有内置字段

```python
Field
    required=True,               是否允许为空
    widget=None,                 HTML插件
    label=None,                  用于生成Label标签或显示内容
    initial=None,                初始值
    help_text='',                帮助信息(在标签旁边显示)
    error_messages=None,         错误信息 {'required': '不能为空', 'invalid': '格式错误'}
    validators=[],               自定义验证规则
    localize=False,              是否支持本地化
    disabled=False,              是否可以编辑
    label_suffix=None            Label内容后缀
 
 
CharField(Field)
    max_length=None,             最大长度
    min_length=None,             最小长度
    strip=True                   是否移除用户输入空白
 
IntegerField(Field)
    max_value=None,              最大值
    min_value=None,              最小值
 
FloatField(IntegerField)
    ...
 
DecimalField(IntegerField)
    max_value=None,              最大值
    min_value=None,              最小值
    max_digits=None,             总长度
    decimal_places=None,         小数位长度
 
BaseTemporalField(Field)
    input_formats=None          时间格式化   
 
DateField(BaseTemporalField)    格式：2015-09-01
TimeField(BaseTemporalField)    格式：11:12
DateTimeField(BaseTemporalField)格式：2015-09-01 11:12
 
DurationField(Field)            时间间隔：%d %H:%M:%S.%f
    ...
 
RegexField(CharField)
    regex,                      自定制正则表达式
    max_length=None,            最大长度
    min_length=None,            最小长度
    error_message=None,         忽略，错误信息使用 error_messages={'invalid': '...'}
 
EmailField(CharField)      
    ...
 
FileField(Field)
    allow_empty_file=False     是否允许空文件
 
ImageField(FileField)      
    ...
    注：需要PIL模块，pip3 install Pillow
    以上两个字典使用时，需要注意两点：
        - form表单中 enctype="multipart/form-data"
        - view函数中 obj = MyForm(request.POST, request.FILES)
 
URLField(Field)
    ...
 
 
BooleanField(Field)  
    ...
 
NullBooleanField(BooleanField)
    ...
 
ChoiceField(Field)
    ...
    choices=(),                选项，如：choices = ((0,'上海'),(1,'北京'),)
    required=True,             是否必填
    widget=None,               插件，默认select插件
    label=None,                Label内容
    initial=None,              初始值
    help_text='',              帮助提示
 
 
ModelChoiceField(ChoiceField)
    ...                        django.forms.models.ModelChoiceField
    queryset,                  # 查询数据库中的数据
    empty_label="---------",   # 默认空显示内容
    to_field_name=None,        # HTML中value的值对应的字段
    limit_choices_to=None      # ModelForm中对queryset二次筛选
     
ModelMultipleChoiceField(ModelChoiceField)
    ...                        django.forms.models.ModelMultipleChoiceField
 
 
     
TypedChoiceField(ChoiceField)
    coerce = lambda val: val   对选中的值进行一次转换
    empty_value= ''            空值的默认值
 
MultipleChoiceField(ChoiceField)
    ...
 
TypedMultipleChoiceField(MultipleChoiceField)
    coerce = lambda val: val   对选中的每一个值进行一次转换
    empty_value= ''            空值的默认值
 
ComboField(Field)
    fields=()                  使用多个验证，如下：即验证最大长度20，又验证邮箱格式
                               fields.ComboField(fields=[fields.CharField(max_length=20), fields.EmailField(),])
 
MultiValueField(Field)
    PS: 抽象类，子类中可以实现聚合多个字典去匹配一个值，要配合MultiWidget使用
 
SplitDateTimeField(MultiValueField)
    input_date_formats=None,   格式列表：['%Y--%m--%d', '%m%d/%Y', '%m/%d/%y']
    input_time_formats=None    格式列表：['%H:%M:%S', '%H:%M:%S.%f', '%H:%M']
 
FilePathField(ChoiceField)     文件选项，目录下文件显示在页面中
    path,                      文件夹路径
    match=None,                正则匹配
    recursive=False,           递归下面的文件夹
    allow_files=True,          允许文件
    allow_folders=False,       允许文件夹
    required=True,
    widget=None,
    label=None,
    initial=None,
    help_text=''
 
GenericIPAddressField
    protocol='both',           both,ipv4,ipv6支持的IP格式
    unpack_ipv4=False          解析ipv4地址，如果是::ffff:192.0.2.1时候，可解析为192.0.2.1， PS：protocol必须为both才能启用
 
SlugField(CharField)           数字，字母，下划线，减号（连字符）
    ...
 
UUIDField(CharField)           uuid类型

```

##### 3、校验

方式一：

```python
from django.forms import Form
from django.forms import widgets
from django.forms import fields
from django.core.validators import RegexValidator
 
class MyForm(Form):
    user = fields.CharField(
        validators=[RegexValidator(r'^[0-9]+$', '请输入数字'), RegexValidator(r'^159[0-9]+$', '数字必须以159开头')],
    )
```



方式二：

```python
import re
from django.forms import Form
from django.forms import widgets
from django.forms import fields
from django.core.exceptions import ValidationError
 
 
# 自定义验证规则
def mobile_validate(value):
    mobile_re = re.compile(r'^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$')
    if not mobile_re.match(value):
        raise ValidationError('手机号码格式错误')
 
 
class PublishForm(Form):
 
 
    title = fields.CharField(max_length=20,
                            min_length=5,
                            error_messages={'required': '标题不能为空',
                                            'min_length': '标题最少为5个字符',
                                            'max_length': '标题最多为20个字符'},
                            widget=widgets.TextInput(attrs={'class': "form-control",
                                                          'placeholder': '标题5-20个字符'}))
 
 
    # 使用自定义验证规则
    phone = fields.CharField(validators=[mobile_validate, ],
                            error_messages={'required': '手机不能为空'},
                            widget=widgets.TextInput(attrs={'class': "form-control",
                                                          'placeholder': u'手机号码'}))
 
    email = fields.EmailField(required=False,
                            error_messages={'required': u'邮箱不能为空','invalid': u'邮箱格式错误'},
                            widget=widgets.TextInput(attrs={'class': "form-control", 'placeholder': u'邮箱'}))
```

校验的源码剖析：

首先针对max_lenth参数的剖析；

```
reg_obj = Regirst(request.POST)
```

- 实例化

- 在CharField中__init__方法

    - ```
        if min_length is not None:    self.validators.append(validators.MinLengthValidator(int(min_length)))if max_length is not None:    self.validators.append(validators.MaxLengthValidator(int(max_length)))
        ```

    - ```
        class MinLengthValidator(BaseValidator)
        继续找父集
        lass BaseValidator(object):
            message = _('Ensure this value is %(limit_value)s (it is %(show_value)s).')
            code = 'limit_value'
        
            def __init__(self, limit_value, message=None):
                self.limit_value = limit_value
                if message:
                    self.message = message
         将max_lenth的值给limit_value
        
        
        ```

    - 在进行校验时会调用此方法：

    - ```python
        def __call__(self, value):  
          cleaned = self.clean(value)    params = {'limit_value': self.limit_value, 'show_value': cleaned, 'value': value}    if self.compare(cleaned, self.limit_value):        raise ValidationError(self.message, code=self.code, params=params)
        ```

    - ```python
            def compare(self, a, b):
                return a is not b
        ```

    - 如果max_len和计算的长度不相等则直接返回true

    - __call__ 抛出异常。

is_valid()校验：

- 第一步：校验是否为空return self.is_bound and not self.errors

-  self.is_bound判断是否为空self.is_bound = data is not None or files is not None

- 第二步是否剖出异常，有错误 not self.errors

- 执行self.full_clean()，生成错误字典self._errors = ErrorDict()

- 随后执行

- ```python
    self._clean_fields()
    self._clean_form()
    self._post_clean()
    ```









##### 4、进阶

###### 应用Bootstrap样式

```python
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="x-ua-compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="/static/bootstrap/css/bootstrap.min.css">
  <title>login</title>
</head>
<body>
<div class="container">
  <div class="row">
    <form action="/login2/" method="post" novalidate class="form-horizontal">
      {% csrf_token %}
      <div class="form-group">
        <label for="{{ form_obj.username.id_for_label }}"
               class="col-md-2 control-label">{{ form_obj.username.label }}</label>
        <div class="col-md-10">
          {{ form_obj.username }}
          <span class="help-block">{{ form_obj.username.errors.0 }}</span>
        </div>
      </div>
      <div class="form-group">
        <label for="{{ form_obj.pwd.id_for_label }}" class="col-md-2 control-label">{{ form_obj.pwd.label }}</label>
        <div class="col-md-10">
          {{ form_obj.pwd }}
          <span class="help-block">{{ form_obj.pwd.errors.0 }}</span>
        </div>
      </div>
      <div class="form-group">
      <label class="col-md-2 control-label">{{ form_obj.gender.label }}</label>
        <div class="col-md-10">
          <div class="radio">
            {% for radio in form_obj.gender %}
              <label for="{{ radio.id_for_label }}">
                {{ radio.tag }}{{ radio.choice_label }}
              </label>
            {% endfor %}
          </div>
        </div>
      </div>
      <div class="form-group">
        <div class="col-md-offset-2 col-md-10">
          <button type="submit" class="btn btn-default">注册</button>
        </div>
      </div>
    </form>
  </div>
</div>

<script src="/static/jquery-3.2.1.min.js"></script>
<script src="/static/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
```

###### 批量添加样式

可通过重写form类的init方法来实现。

```python
class LoginForm(forms.Form):
    username = forms.CharField(
        min_length=8,
        label="用户名",
        initial="张三",
        error_messages={
            "required": "不能为空",
            "invalid": "格式错误",
            "min_length": "用户名最短8位"
        }
    ...

    def __init__(self, *args, **kwargs):
        super(LoginForm, self).__init__(*args, **kwargs)
        for field in iter(self.fields):
            self.fields[field].widget.attrs.update({
                'class': 'form-control'
            })
```



##### 5、ModelForm

form与model的终极结合。

```python
class BookForm(forms.ModelForm):

    class Meta:
        model = models.Book
        fields = "__all__"
        labels = {
            "title": "书名",
            "price": "价格"
        }
        widgets = {
            "password": forms.widgets.PasswordInput(attrs={"class": "c1"}),
        }
```

 class Meta:下常用参数：

```python
model = models.Student  # 对应的Model中的类
fields = "__all__"  # 字段，如果是__all__,就是表示列出所有的字段
exclude = None  # 排除的字段
labels = None  # 提示信息
help_texts = None  # 帮助提示信息
widgets = None  # 自定义插件
error_messages = None  # 自定义错误信息
```







##### 6、总结

form组件

form

1. 有input让用户输入
2. 提交数据

form组件

1. 提供input框
2. 能对数据做校验
3. 返回错误提示

定义：

```
from django import forms
class RegForm(forms.Form):
    username = forms.CharField(label='用户名')
    password = forms.CharField(label='密码')
```

使用：

```
函数
def register2(request):
    if request.method == 'POST':
        form_obj = RegForm(request.POST)

        if form_obj.is_valid():  # 校验数据
            # 插入数据库
            print(form_obj.cleaned_data)
            print(request.POST)

            return HttpResponse('注册成功')
    else:
        form_obj = RegForm()
    return render(request, 'register2.html', {'form_obj': form_obj})

```

```
模板
{{ form_obj.as_p }}   # 展示所有的字段

{{ form_obj.username }}           #  生成input框
{{ form_obj.username.label }}     #  中文提示
{{ form_obj.username.id_for_label }}    # input框的id
{{ form_obj.username.errors }}     # 该字段的所有的错误
{{ form_obj.username.errors.0 }}    # 该字段的第一个的错误

{{ form_obj.errors }}    # 该form表单中所有的错误

```

常用字段：

```
CharField      # 文本输入框
ChoiceField    # 单选框
MultipleChoiceField  # 多选框
```

字段参数：

```
    required=True,               是否必填
    widget=None,                 HTML插件
    label=None,                  用于生成Label标签或显示内容
    initial=None,                初始值
    error_messages=None,         错误信息 {'required': '不能为空', 'invalid': '格式错误'} 
    disabled=False,              是否可以编辑
    validators=[],               自定义验证规则


```

校验

校验顺序：

每隔字段：

- 内置校验规则 field.validate（必填  长度）

- 校验器field.run_validators(默认校验器，自定义的校验器)

- 局部钩子form_obj.clean_字段名

- 
- 全局钩子 clean 



自定义校验规则

1. 写函数

    ```
    from django.core.exceptions import ValidationError
    
    def checkusername(value):
    	# 通过校验规则  什么事都不用干
    	# bu通过校验规则  抛出异常ValidationError
        if models.User.objects.filter(username=value):
            raise ValidationError('用户名已存在')
            
    username = forms.CharField(
    
            validators=[checkusername,]）
    
    ```

2. 用内置的校验器

    ```
    from django.core.validators import RegexValidator
    
    phone = forms.CharField(min_length=11,max_length=11,validators=[RegexValidator(r'^1[3-9]\d{9}$','手机号格式不正确')])
    
    
    ```

    

局部钩子和全局钩子

```python
    def clean(self):
        # 全局钩子
        # 通过校验   返回self.cleaned_data
        # 不通过校验   抛出异常
        password = self.cleaned_data.get('password')
        re_password = self.cleaned_data.get('re_password')
        if password == re_password:
            return self.cleaned_data
        else:
            self.add_error('password','两次密码不一致!!')
            raise ValidationError('两次密码不一致')

    def clean_username(self):
        # 局部钩子
        # 通过校验   返回当前字段的值
        # 不通过校验   抛出异常
        value = self.cleaned_data.get('username')
        if models.User.objects.filter(username=value):
            raise ValidationError('用户名已存在')
        return value

```





  











### 11.django的认证系统 --- auth

#### 1.django 自带的用户认证

我们在开发一个网站的时候，无可避免的需要设计实现网站的用户系统。此时我们需要实现包括用户注册、用户登录、用户认证、注销、修改密码等功能，这还真是个麻烦的事情呢。

Django作为一个完美主义者的终极框架，当然也会想到用户的这些痛点。它内置了强大的用户认证系统--auth，它默认使用 auth_user 表来存储用户数据。

#### 2.auth模块

导入模块

```python
from django.contrib  import auth
```

auth 中提供了很多实用方法：

##### 1.authenticate()

提供了用户认证功能，即验证用户名以及密码是否正确，一般需要username 、password两个关键字参数。

如果认证成功（用户名和密码正确有效），便会返回一个 User 对象。

authenticate()会在该 User 对象上设置一个属性来标识后端已经认证了该用户，且该信息在后续的登录过程中是需要的。

用法：

```python
user = auth.authenticate(request,username='theuser',password='thepassword')
```



##### 2.login(HttpRequest,user)

该函数接受一个HttpRequest对象，以及一个经过认证的User对象。

该函数实现一个用户登录的功能。它本质上会在后端为该用户生成相关session数据。

用法：

```python
from django.contrib.auth import authenticate, login
   
def my_view(request):
  username = request.POST['username']
  password = request.POST['password']
  user = authenticate(request, username=username, password=password)
  if user is not None:
    login(request, user)
    # Redirect to a success page.
    ...
  else:
    # Return an 'invalid login' error message.
    ...
```



##### 3.logout(request):

该函数接受一个HttpRequest对象，无返回值。

当调用该函数时，当前请求的session信息会全部清除。该用户即使没有登录，使用该函数也不会报错。

用法：

```python
from django.contrib.auth import logout
   
def logout_view(request):
  logout(request)
  # Redirect to a success page.

```

##### 4.is_authenticated()

用来判断当前请求是否通过了认证

用法:

```python
def my_view(request):
  if not request.user.is_authenticated():
    return redirect('%s?next=%s' % (settings.LOGIN_URL, request.path))
```

##### 5.login_requierd()

auth 给我们提供的一个装饰器工具，用来快捷的给某个视图添加登录校验。

用法：

```python
from django.contrib.auth.decorators import login_required
      
@login_required
def my_view(request):
  ...
```

若用户没有登录，则会跳转到django默认的 登录URL '/accounts/login/ ' 并传递当前访问url的绝对路径 (登陆成功后，会重定向到该路径)。

如果需要自定义登录的URL，则需要在settings.py文件中通过LOGIN_URL进行修改。

示例：

```python
LOGIN_URL = '/login/'  # 这里配置成你项目登录页面的路由
```

##### 6.create_user()

auth 提供的一个创建新用户的方法，需要提供必要参数（username、password）等。

用法：

```python
from django.contrib.auth.models import User
user = User.objects.create_user（username='用户名',password='密码',email='邮箱',...）
```

##### 7.create_superuser()

auth 提供的一个创建新的超级用户的方法，需要提供必要参数（username、password）等。

用法：

```python
from django.contrib.auth.models import User
user = User.objects.create_superuser（username='用户名',password='密码',email='邮箱',...）
```



##### 8.check_password(password)

auth 提供的一个检查密码是否正确的方法，需要提供当前请求用户的密码。

密码正确返回True，否则返回False。

用法：

```python
ok = user.check_password('密码')
```

##### 9.set_password(password)

auth 提供的一个修改密码的方法，接收 要设置的新密码 作为参数。

注意：设置完一定要调用用户对象的save方法！！！

用法：

```python
user.set_password(password='')
user.save()
```

### 12、用户模型类（AbstractUser介绍）

AbstaractUser介绍：

- User对象基本属性：
    - 创建用户必选：username,password
    - 创建用户可选：email、first_name、last_name、last_login、date_joined、is_active 、is_staff、is_superuse
    - 判断用户是否通过认证：is_authenticated

- 创建用户的方法：

    ```python
    user = User.objects.create_user(username, email, password, **extra_fields)
    ```

- 用户认证的方法：

    - > Django 自带用户认证系统
        > 它处理用户账号、组、权限以及基于 cookie 的用户会话

        - Django 认证系统同时处理认证和授权
            - 认证：验证一个用户是否它声称的那个人，可用于账号登录.
            - 授权：授权决定一个通过了认证的用户被允许做什么.
        - Django 认证系统包含的内容
            - 用户：用户模型类、用户认证.
            - 权限：标识一个用户是否可以做一个特定的任务，MIS 系统常用到.
            - 组：对多个具有相同权限的用户进行统一管理，MIS 系统常用到.
            - 密码：一个可配置的密码哈希系统，设置密码、密码校验.

    ```
    from django.contrib.auth import authenticate
    
     #进行认证校验, 查看用户是否是声明的那一个
      user = authenticate(username=username, password=password, **kwargs)
    ```

    - **处理密码的方法**

    ```
    设置密码：set_password(raw_password)
    校验密码：check_password(raw_password)
    ```

自定义用户模型类

```
# 导入
from django.db import models
from django.contrib.auth.models import AbstractUser

# 我们重写用户模型类, 继承自 AbstractUser
class User(AbstractUser):
    """自定义用户模型类"""

    # 在用户模型类中增加 mobile 字段
    mobile = models.CharField(max_length=11, unique=True, verbose_name='手机号')

    # 对当前表进行相关设置: 
    class Meta:
        db_table = 'tb_users'
        verbose_name = '用户'
        verbose_name_plural = verbose_name

    # 在 str 魔法方法中, 返回用户名称
    def __str__(self):
        return self.username
```

[Django 用户认证系统说明文档](https://yiyibooks.cn/xx/Django_1.11.6/topics/auth/index.html)

指定用户模型类

- Django 用户模型类是通过全局配置项 AUTH_USER_MODEL 决定的
    又因为我们重写了用户模型类, 所以我们需要重新指定默认的用户模型类:
- 在 dev.py 文件中添加如下代码:

```
# 指定本项目用户模型类

AUTH_USER_MODEL = 'users.User'
```

## django项目阶段：

#### 1、modelform

Model ==> 强大的数据库操作，弱小的数据验证。

Form ==>强大的数据验证

ModelForm ===>二者结合，强大的数据验证，适中的数据库操作。在ModelForm是能够封装一个model对象。

#### 2、**Form和ModelForm的继承关系：**

```
Form:
    继承关系：
        UserForm -- > Form -- >BaseForm
ModelForm: 
    继承关系：
        NewsModelForm -->ModelForm -->BaseModelForm -->BaseForm 
        
        
所以modelForm和Form是有同一个祖宗的，Form中的BaseForm的功能，ModelForm也一样可以使用。
```

```python
from django import forms
from app01 import models
class RegForm(forms.ModelForm):
     password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': '密码'}))
	 re_password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': '确认密码'}))
    
    class Meta:
        model = models.User
        fileds = '__all__'  # ['name','']
        exclude = ['is_active']
        
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
    def clean(self):
        self._validate_unique = True  # 在数据库校验唯一性
        return self.cleaned_data
    
 使用：
form_obj = RegForm()

{{ form_obj.username }}   _>  input 
{{ form_obj.username.errors }}   _> 所有的错误
{{ form_obj.username.label }}   _>  提示 
{{ form_obj.username.id_for_label }}   _>  input的id
{{ form_obj.errors }}   _>  所有的错误


form_obj = RegForm(request.POST)

form_obj.is_valid()  #数据校验
form_obj.save() # 保存数据
```

#### 3、展示数据

```
[对象，对象]
1. 普通字段
	对象.字段名  ——》  数据库的值
2. 有choices参数的字段
	（（1,'男’），）
	对象.字段名  ——》  数据库的值  1 
	对象.get_字段名_display()  ——》  显示的内容 
	
3. 自定义方法
	def show_class(self):
		return  ','.join([  str(i) for i in self.class_list.all()])
	
    from django.utils.safestring import mark_safe
    
```

#### 4、分页：

自定义分页类

```python
# 分页class

class Pagination:
    def __init__(self, page, count_data, per_num=10, max_show=11):
        """
        :param page: 页码
        :param count_data: 数据总数量
        :param per_num: 页面中最多显示的数据行数
        :param max_show:页面中最多显示的页码数
        """
        try:
            page = int(page)
            if page <= 0:
                page = 1
        except Exception:
            page = 1

        self.page = page
        self.per_num = per_num
        self.count_data = count_data
        self.max_show = max_show
        self.sum_page_num_nu = 0
        self.sum_page_num = 0

    @property
    def start(self):
        if (self.page - 1) * self.per_num > self.count_data:
            self.page = self.sum_pagination()
        return (self.page - 1) * self.per_num

    @property
    def end(self):
        if self.page * self.per_num > self.count_data:
            self.page = self.sum_pagination()
        return self.page * self.per_num

    def sum_pagination(self):
        self.sum_page_num, self.more = divmod(self.count_data, self.per_num)  # 计算总页码数
        if self.more:  # 有余数时，页码数+1
            self.sum_page_num += 1
        return self.sum_page_num

    @property
    def page_html(self):
        """
        :return:页面显示的html代码
        """
        self.sum_page_num_nu = self.sum_pagination()

        half_show = self.max_show // 2

        if self.sum_page_num_nu < self.max_show:
            # 页码数量超过显示的最大页码数
            page_start = 1
            page_end = self.sum_page_num_nu
        else:
            if self.page - half_show < 0:
                page_start = 1
                page_end = self.max_show
            elif self.page + half_show > self.sum_page_num_nu:
                page_end = self.sum_page_num_nu
                page_start = self.sum_page_num_nu - self.max_show + 1
            else:
                page_start = self.page - half_show
                page_end = self.page + half_show
        page_html_lis = []
        if self.page == 1:
            page_html_lis.append(
                '<li class="disabled"><a aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>')
        else:
            page_html_lis.append(
                '<li><a href="?page={}" aria-label="Previous"><span aria-hidden="true">&laquo;</span></a></li>'.format(
                    self.page - 1))
        for i in range(page_start, page_end + 1):
            if i == self.page:
                page_html_lis.append('<li class="active"><a href="?page={}">{}</a></li>'.format(i, i))
            else:
                page_html_lis.append('<li><a href="?page={}">{}</a></li>'.format(i, i))
        if self.page == self.sum_page_num_nu:
            page_html_lis.append(
                '<li class="disabled"><a aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>')
        else:
            page_html_lis.append(
                '<li><a href="?page={}" aria-label="Next"><span aria-hidden="true">&raquo;</span></a></li>'.format(
                    self.page + 1))

        st = "".join(page_html_lis)
        return st

```

django 提供的分页类：

分页功能是几乎所有的网站上都需要提供的功能，当你要展示的条目比较多时，必须进行分页，不但能减小数据库读取数据压力，也有利于用户浏览。

Django又很贴心的为我们提供了一个Paginator分页工具，但是不幸的是，这个工具功能差了点，不好添加CSS样式，所以前端的展示效果比较丑。

向Paginator提供包含一些对象的列表，以及你想每一页显示几条，比如每页5条、10条、20条、100条等等，它就会为你提供访问的一系列API方法

```python
>>> from django.core.paginator import Paginator
>>> objects = ['john', 'paul', 'george', 'ringo']
>>> p = Paginator(objects, 2)  # 对objects进行分页，虽然objects只是个字符串列表，但没关系，一样用。每页显示2条。

>>> p.count   # 对象个数
4
>>> p.num_pages  # 总共几页
2
>>> type(p.page_range)  # `<type 'rangeiterator'>` in Python 2.
<class 'range_iterator'>
>>> p.page_range  # 分页范围
range(1, 3)

>>> page1 = p.page(1) # 获取第一页
>>> page1
<Page 1 of 2>
>>> page1.object_list # 获取第一页的对象
['john', 'paul']

>>> page2 = p.page(2)
>>> page2.object_list
['george', 'ringo']
>>> page2.has_next()  # 判断是否有下一页
False
>>> page2.has_previous()# 判断是否有上一页
True
>>> page2.has_other_pages() # 判断是否有其它页
True
>>> page2.next_page_number() # 获取下一页的页码
Traceback (most recent call last):
...
EmptyPage: That page contains no results
>>> page2.previous_page_number() # 获取上一页的页码
1
>>> page2.start_index() # 从1开始计数的当前页的第一个对象
3
>>> page2.end_index() # 从1开始计数的当前页最后1个对象
4

>>> p.page(0)  # 访问不存在的页面
Traceback (most recent call last):
...
EmptyPage: That page number is less than 1
>>> p.page(3) # 访问不存在的页面
Traceback (most recent call last):
...
EmptyPage: That page contains no results
  
  """
  简单地说，使用Paginator分四步走：

使用任何方法，获取要展示的对象列表QuerySet；
将列表和每页个数传递给Paginator，返回一个分页对象；
调用该对象的各种方法，获取各种分页信息；
在HTML模板中，使用上面的分页信息构建分页栏。
  """
  Paginator对象属性：
count 对象数量 
num_pages 总页数 
page_range 所有页数范围的生成器
  object_list 当前页的对象列表 
has_next() 有无下一页 
has_ previous() 有无上一页 
has_other_pages() 有无其他页 
next_page_number() 下一页页码 
previous_page_number() 上一页页码 
start_index() 返回当前页第一个对象的在所有对象中的索引，注意，从1开始 
end_index() 返回当前页最后一个对象在所有对象中的索引，注意，从1开始 
paginator 所关联的Paginator对象
```

案例：

views.py

```python
from django.shortcuts import render
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
# Create your views here.
Users = [{'user': 'nihao{}'.format(i), 'password': 'hello_{}'.format(i)} for i in range(1, 478)]
def index(request):
    paginator = Paginator(Users,2)
    print(paginator.count)
    print(paginator.page_range)
    page = request.GET.get('page')
    try:
        contacts = paginator.page(page)
    except PageNotAnInteger:
        # 如果请求的页数不是整数，返回第一页。
        contacts = paginator.page(1)
    except EmptyPage:
        # 如果请求的页数不在合法的页数范围内，返回结果的最后一页。
        contacts = paginator.page(paginator.num_pages)
    return render(request, 'index.html', {'contacts': contacts})
```

html

```html
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>分页器</title>
    <script src="https://cdn.staticfile.org/jquery/1.10.2/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>
<body>
<div style="width: 1000px;margin: 50px auto">
    <table class="table  table-hover">
        <thead>
        <tr>
            <th>序号</th>
            <th>用户名</th>
            <th>密码</th>
        </tr>
        </thead>
        <tbody>
        {% for contact in contacts %}
            <tr>
                <td>{{ forloop.counter }}</td>
                <td>{{ contact.user }}</td>
                <td>{{ contact.password }}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</div>


{# 分页标签的HTML代码 #}
<div style="width: 400px;margin: 20px auto">
    <div class="pagination">
    <span class="step-links">
        {% if contacts.has_previous %}
            <a href="?page={{ contacts.previous_page_number }}">上一页</a>
        {% endif %}
        <span class="current">
            当前：{{ contacts.number }}
            <input type="text" id="zd"  url ="?page="> <a class="zda" href="javascript::;" onclick="changeurl()">转到</a>
            总数：<input type="text" width="40px" value="{{ contacts.paginator.num_pages }}" disabled>
        </span>
        {% if contacts.has_next %}
            <a href="?page={{ contacts.next_page_number }}">下一页</a>
        {% endif %}
    </span>
    </div>
</div>
<script>
    function changeurl() {
        $('.zda').attr('href',"?page="+$('#zd').val());
    }
</script>

</body>
</html>
```

url

```python
urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'index',views.index)
]
```

Paginator对象

Paginator类拥有以下方法和属性：

**方法：**

Paginator.page(number)[source]

返回指定页面的对象列表，比如第7页的所有内容，下标以1开始。如果提供的页码不存在，抛出InvalidPage异常。

**属性**：

- Paginator.count：所有页面的对象总数。
- Paginator.num_pages：页面总数。
- Paginator.page_range：基于1的页数范围迭代器。

处理异常

在实际使用中，可能恶意也可能不小心，用户请求的页面，可能千奇百怪。正常我们希望是个合法的1，2，3之类，但请求的可能是‘apple’，‘1000000’，‘#’，这就有可能导致异常，需要特别处理。Django为我们内置了下面几个，Paginator相关异常。

- exception InvalidPage[source]：异常的基类，当paginator传入一个无效的页码时抛出。
- exception PageNotAnInteger[source]：当向page()提供一个不是整数的值时抛出。
- exception EmptyPage[source]：当向page()提供一个有效值，但是那个页面上没有任何对象时抛出。

后面两个异常都是InvalidPage的子类，所以你可以通过简单的except InvalidPage来处理它们。

Page对象

Paginator.page()将返回一个Page对象，我们主要的操作都是基于Page对象的，它具有下面的方法和属性：

**方法**：

- Page.has_next()[source]：如果有下一页，则返回True。
- Page.has_previous()[source]：如果有上一页，返回 True。
- Page.has_other_pages()[source]：如果有上一页或下一页，返回True。
- Page.next_page_number()[source]：返回下一页的页码。如果下一页不存在，抛出InvalidPage异常。
- Page.previous_page_number()[source]：返回上一页的页码。如果上一页不存在，抛出InvalidPage异常。
- `Page.start_index()[source]`：返回当前页上的第一个对象，相对于分页列表的所有对象的序号，从1开始计数。 比如，将五个对象的列表分为每页两个对象，第二页的`start_index()`会返回3。
- `Page.end_index()[source]`:返回当前页上的最后一个对象，相对于分页列表的所有对象的序号，从1开始。 比如，将五个对象的列表分为每页两个对象，第二页的`end_index()`会返回4。

**属性**:

- Page.object_list:当前页上所有对象的列表。
- Page.number:当前页的序号，从1开始计数。
- Page.paginator：当前Page对象所属的Paginator对象。

#### 5、模板中使用form表单 field.field





#### 6、django-QueryDict对象

 `HttpRequest` 对象中,属性 GET 和 POST 得到的都是 `django.http.QueryDict` 所创建的实例。这是一个 django 自定义的类似字典的类，用来处理同一个键带多个值的情况。

　　在 python 原始的字典中，当一个键出现多个值的时候会发生冲突，只保留最后一个值。而在 HTML 表单中，通常会发生一个键有多个值的情况，例如 `<select multiple>` （多选框）就是一个很常见情况。

　　`request.POST` 和`request.GET` 的`QueryDict` 在一个正常的请求/响应循环中是不可变的。若要获得可变的版本，需要使用`.copy()方法。`

request.GET或者是request.POST 获取到的是QueryDict，继承dict类

QueryDict类中的方法:

1、QueryDict.__init__(**query_string=None, mutable=False, encoding=None**)

这是一个构造函数，其中 query_string 需要一个字符串，

```python
 QueryDict('a=1&a=2&c=3')
<QueryDict: {'a': ['1', '2'], 'c': ['3']}>
```

-  query_string 没有传入，则获得一个空的对象。

- 实例化一个对象，可以传递 mutable=True 使你所实例化的对象可变;

-  request.POST 和 request.GET 是django创建,如果需要修改内部值，需要将mutable =True

- 对于设置的键和值，会从 encoding 转码成 Unicode

- ```
    如果传入的字符串 query_string  是 GBK 或者是 utf-8 的编码，将会自动转码成 Unicode，然后用做字典的键和值。如果 encoding = None，也就是没有设定的话，将使用 DEFAULT_CHARSET 的值，默认为：'utf-8'
    ```

2、QueryDict.__getitem__(key):

返回给出的 key 的值。如果key 具有多个值，`__getitem__()` 返回**最后**（最新）的值。如果 key 不存在，则引发`django.utils.datastructures.MultiValueDictKeyError`。（它是Python 标准`KeyError` 的一个子类，所以你仍然可以坚持捕获`KeyError`。） 

3、**.QueryDict.__setitem__(key, value)**

　　设置给出的 key 的值为`[value]`（一个Python 列表，只有一个元素 value）。注意：只有对象是可以改变的时候才能使用，例如通过 .copy() 方法创建的对象。

源码剖析：

```python
class QueryDict():
   def __setitem__(self, key, value):
        self._assert_mutable()
        key = bytes_to_text(key, self.encoding)
        value = bytes_to_text(value, self.encoding)
        super(QueryDict, self).__setitem__(key, value)
"""
self._assert_mutable(): 进行校验，判断是否可以编辑
    def _assert_mutable(self):
        if not self._mutable:
            raise AttributeError("This QueryDict instance is immutable")
   如果self._mutable = Flase  表示不可以编辑，则会抛出异常“This QueryDict instance is immutable”
"""
"""
key = bytes_to_text(key, self.encoding)  执行：
键和值会以unicode存储
"""

```

4、**.QueryDict.\__contains\__(key)**

　　如果给出的key 已经设置，则返回`True`。它让你可以做 if "foo" in request.GET  这样的操作

**5.QueryDict.get(key, default)**

　　使用与上面`__getitem__()` 相同的逻辑，但是当key 不存在时返回一个默认值。

 

**6.QueryDict.setdefault(key, default)**

　　类似标准字典的`setdefault()` 方法，只是它在内部使用的是`__setitem__()`。也就是说，当key已经存在时，返回其值，key不存在时，返回default，同时添加 key 和 default到对象中。

 

**7.QueryDict.update(other_dict)**

　　接收一个`QueryDict` 或标准字典。类似标准字典的`update()` 方法，但是它附加到当前字典项的后面，而不是替换掉它们。

```python
>>> q = QueryDict('a=1', mutable=True)    # 当然要可变的才能使用
>>> q.update({'a': '2'})
>>> q.getlist('a')
['1', '2']
>>> q['a'] # returns the last
['2']
```

**8.QueryDict.items()**

　　类似标准字典的`items()` 方法，返回一个由键值组成的元祖的列表。但是它使用的是和`__getitem__` 一样返回最新的值的逻辑。

例如：

```
>>> q = QueryDict('a=1&a=2&a=3')
>>> q.items()
[('a', '3')]
```

 

 

**9.QueryDict.iteritems()**

　　类似标准字典的`iteritems()` 方法，返回一个迭代对象。类似 `QueryDict.items()`，它使用的是和`QueryDict.__getitem__()` 一样的返回最新的值的逻辑。

 

**10.QueryDict.iterlists()**

　　类似`QueryDict.iteritems()`，返回一个包含键值对的元祖(key, value)迭代对象 ，value 是一个包括所有 key 的值的列表。

 

**11.QueryDict.values()**

　　类似标准字典的`values()` 方法，但是它使用的是和`__getitem__` 一样返回最新的值的逻辑。也就是返回一个所有键对应的最新值的列表。

例如：

```
>>> q = QueryDict('a=1&a=2&a=3')
>>> q.values()
['3']
```



**12.QueryDict.itervalues()**

　　类似`QueryDict.values()`，只是它返回的是一个迭代器。

**13.QueryDict.copy()**

　　返回对象的副本，使用Python 标准库中的`copy.deepcopy()`。此副本是可变的即使原始对象是不可变的。

源码剖析：

```python
    def copy(self):
        """Returns a mutable copy of this object."""
        return self.__deepcopy__({})

  def __deepcopy__(self, memo):
        result = self.__class__('', mutable=True, encoding=self.encoding)  #实例化一个对象QueryDict对象
        memo[id(self)] = result
        for key, value in six.iterlists(self):
            result.setlist(copy.deepcopy(key, memo), copy.deepcopy(value, memo))   #进行深度拷贝
        return result
 """
 self.__class__()  等价于   QueryDict（）
 """
 所以，QueryDict.copy() 默认将mutable设置为True  默认是可编辑
```



 

**14.QueryDict.getlist(key, default)**

　　以Python 列表形式返回所请求的键的数据。如果键不存在并且没有提供默认值，则返回空列表。它保证返回的是某种类型的列表，除非默认值不是列表。

 

**15.QueryDict.setlist(key, list_)**

　　为给定的键设置`list_`（与`__setitem__()` 不同)，可以设置一个多元素的列表。

 

**16.QueryDict.appendlist(key, item)**

　　将项追加到内部与键相关联的列表中。

 

**17.QueryDict.setlistdefault(key, default_list)**

　　类似`setdefault`，除了它接受一个列表而不是单个值。

 

**18.QueryDict.lists()**

　　类似`items`，只是它将字典中的每个成员作为列表。也就是说，列表中的每个元素，都是由键和对应的值列表组成的二元元祖。

例如：

```
>>> q = QueryDict('a=1&a=2&a=3')
>>> q.lists()
[('a', ['1', '2', '3'])]
```

 

 

**19.QueryDict.pop(key)**

　　返回给定键的值的**列表**，并从字典中移除它们。如果键不存在，将引发`KeyError`。

例如 ︰

```
>>> q = QueryDict('a=1&a=2&a=3', mutable=True)
>>> q.pop('a')
['1', '2', '3']
```



**20.QueryDict.popitem()**

　　删除字典**任意**一个成员（因为没有顺序的概念），并返回二值元组，包含键和键的所有值的列表。在一个空的字典上调用时将引发`KeyError`。

例如 ︰

```
>>> q = QueryDict('a=1&a=2&a=3', mutable=True)
>>> q.popitem()
('a', ['1', '2', '3'])
```

 

**21.QueryDict.dict()**

　　返回`QueryDict` 的`dict` 表示形式。对于`QueryDict` 中的每个(key, list)对 ，`dict` 将有(key, item) 对，其中item 是列表中的一个元素，使用与`QueryDict.__getitem__()`相同的逻辑，也就是最新的：

```
>>> q = QueryDict('a=1&a=3&a=5')
>>> q.dict()
{'a': '5'}
```

**22.QueryDict.urlencode([safe])**

　　从数据中返回查询字符串格式。

例如：

```
>>> q = QueryDict('a=2&b=3&b=5')
>>> q.urlencode()
'a=2&b=3&b=5'
```



　　可选地，urlencode 可以传递不需要编码的字符。（这意味着要进行 url 编码

```python
>>> q = QueryDict(mutable=True)
>>> q['next'] = '/a&b/'
>>> q.urlencode(safe='/')
'next=/a%26b/'
```

源码剖析：

```python
  def urlencode(self, safe=None):
        """
        Returns an encoded string of all query string arguments.

        :arg safe: Used to specify characters which do not require quoting, for
            example::

                >>> q = QueryDict(mutable=True)
                >>> q['next'] = '/a&b/'
                >>> q.urlencode()
                'next=%2Fa%26b%2F'
                >>> q.urlencode(safe='/')
                'next=/a%26b/'
        """
        output = []
        if safe:
            safe = force_bytes(safe, self.encoding)

            def encode(k, v):
                return '%s=%s' % ((quote(k, safe), quote(v, safe)))
        else:
            def encode(k, v):
                return urlencode({k: v})
        for k, list_ in self.lists():
            k = force_bytes(k, self.encoding)
            output.extend(encode(k, force_bytes(v, self.encoding))
                          for v in list_)
        return '&'.join(output)
      
      """
      
      
      self.lists() 返回 <dict_itemiterator object at 0x000002F9AF1F2E08> 对象
      k, list_  得到的是
      path ['/index/']
			path ['/index/']
			page [1]
			page [2]
			page [2]
      
      打印print(utput)
      
      ['path=%2Findex%2F']
			['path=%2Findex%2F']
			['page=1']
			['page=2']
			['page=2']
     然后通过join拼接起来。
      """
```



权限管理：

## **Rbac 权限管理：**

　　Role-Based Access Control，**基于角色的访问控制**。用户通过角色与权限进行关联，一个用户可以有多个角色，一个角色可以有多个权限。

构造成“用户-角色-权限”的授权模型。在这种模型中，用户与角色之间，角色与权限之间，一般者是多对多的关系

```python
(rbac模式-role based access control)：
               User
                id   name   age
                 1   alex   23
                 2   egon   45
                 3   peiqi  89
                
               
                Role
                id  title 
                 1   销售
                 2   CEO
                 3   销售总监

                 UserInfo2Role
                 id user_id  role_id
                  1     1        1 
                  2     2        1 
                  3     3        1 
                
                
                permissison
                
                id     title        url      
                 1     查看客户     /stark/crm/customer/ 
                 2     添加客户     /stark/crm/customer/add        
                 3     查看订单     /stark/crm/order/    
                 3     添加订单     /stark/crm/order/add    
                
                 Role2permissison
                 
                 id  role_id   permissison_id
                  1     1            1
                  2     1            2
                  3     1            3
                  4     1            4
```



创建model

```python
from django.db import models


# Create your models here.

class User(models.Model):
    """
    用户表
    """
    user = models.CharField(max_length=20, verbose_name='用户名')
    password = models.CharField(max_length=20, verbose_name='密码')
    roles = models.ManyToManyField('Role', related_name='user', verbose_name='角色')

    class Meta:
        verbose_name = "用户表"
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.user


class Permission(models.Model):
    """
    权限表
    """
    url = models.CharField(max_length=100, verbose_name='链接地址')
    title = models.CharField(max_length=20, verbose_name='标题')

    class Meta:
        verbose_name = '权限表'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.title


class Role(models.Model):
    """
    角色表
    """
    name = models.CharField(max_length=20, verbose_name='角色')
    persisson = models.ManyToManyField('Permission', verbose_name='权限', related_name='role',blank=True)

    class Meta:
        verbose_name = '角色表'
        verbose_name_plural = verbose_name

    def __str__(self):
        return self.name

```

**1.进行数据的迁移，  执行：**

　　python manage.py  makemigrations

　　python manage.py   migrate 

2、在admin中注册 

```py
from django.contrib import admin
from app01 import models
# Register your models here.
class Per(admin.ModelAdmin):
    list_display = ['id','url','title']

admin.site.register(models.Permission,Per)

admin.site.register(models.User)
admin.site.register(models.Role)
```

![1574862760671](django02.assets/1574862760671.png)

进行权限管理或者是判断是否登陆可以使用中间件

1、在app01下面创建middleswares目录，然后再此目录创建my_middle.py

2、再文件中写入process_request

```python

from django.utils.deprecation import MiddlewareMixin
from django.shortcuts import redirect, reverse,HttpResponse
from django.conf import settings
import re


class MD(MiddlewareMixin):

    def process_request(self, request, *args, **kwargs):
        url = request.path_info
				#判断白名单
        for i in settings.WHITE_PATH:  
            if re.match(r"{}".format(i), url):
                return
          
				#判断是否登陆成功
        login_flage = request.session.get('is_login')
        if not login_flage:
            return redirect('/login/')

        # 自定义权限管理
        for i in request.session.get('persisson'):
            if re.match(r'{}'.format(i['persisson__url']),request.path_info):
                return
        else:
            return HttpResponse('你的权限不够')

```

setting.py

```python
WHITE_PATH = [
    '^/login/$',
    '^/index/$',
    '^/admin',
]
```

3、视图函数View.py

```python

from django.shortcuts import render, redirect
from app01 import models


def login(request):
    if request.method == 'POST':
        print(request.POST)
        user = request.POST.get('user')
        password = request.POST.get('password')
        user_obj = models.User.objects.filter(user=user, password=password).first()
        print(user_obj)
        if user_obj:
            # 登陆成功
            request.session['is_login'] = True
            persisson = user_obj.roles.exclude(persisson=None).values('persisson__url').distinct()
            request.session['persisson'] = list(persisson)
            return redirect('/index/')

    return render(request, 'login.html')


def index(request):
    return render(request, 'index.html')

```



