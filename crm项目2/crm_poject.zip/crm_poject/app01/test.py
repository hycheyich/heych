# -*- coding: utf-8 -*-
# @Time    : 2019/11/25 22:44
# @Author  : sunny
# @File    : test.py
# @Software: PyCharm
# @WeChat public address : 程序猿与python之间的秘密


import  struct
# buffer = struct.pack("B", 1, 2, 3)
# print(repr(buffer))
# print(struct.unpack("B", buffer[0:2]))

# t = (32,)
# print(str(t[0]))

